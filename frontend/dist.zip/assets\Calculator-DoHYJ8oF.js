import { r as reactExports, h as fetchScratchcards, j as jsxRuntimeExports, S as SeoHead, m as motion, C as Calculator, i as Search, b as Trophy, L as Link, T as TriangleAlert, a as TrendingUp, P as Percent, F as Flame } from "./index-CZMt6iFz.js";
const SORT_TABS = [
  { key: "hot", label: "熱門排行", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { size: 14 }) },
  { key: "price", label: "價格高低", icon: null },
  { key: "newest", label: "最新上市", icon: null },
  { key: "winRate", label: "中獎率", icon: null }
];
function parseRocDate(dateStr) {
  if (!dateStr) return null;
  const cleaned = dateStr.replace(/\./g, "/");
  const parts = cleaned.split("/");
  if (parts.length !== 3) return null;
  const year = parseInt(parts[0]) + 1911;
  const month = parseInt(parts[1]) - 1;
  const day = parseInt(parts[2]);
  if (isNaN(year) || isNaN(month) || isNaN(day)) return null;
  return new Date(year, month, day);
}
function parseWinRate(winRate) {
  if (!winRate) return 0;
  const num = parseFloat(winRate.replace("%", ""));
  return isNaN(num) ? 0 : num;
}
function isExpired(card) {
  if (card.salesRateValue >= 100) return true;
  const deadline = parseRocDate(card.redeemDeadline);
  if (!deadline) return false;
  return deadline < /* @__PURE__ */ new Date();
}
function isHotCard(card, allCards) {
  if (parseWinRate(card.overallWinRate) > 49) return true;
  const sameName = allCards.filter((c) => c.name === card.name && c.id !== card.id);
  if (sameName.some((c) => c.salesRateValue > 70)) return true;
  if (card.salesRateValue > 70) return true;
  return false;
}
function isNewCard(card) {
  const issueDate = parseRocDate(card.issueDate);
  if (!issueDate) return false;
  const diffDays = Math.floor((Date.now() - issueDate.getTime()) / (1e3 * 60 * 60 * 24));
  return diffDays <= 30;
}
function isSoldOut(card) {
  return card.salesRateValue >= 99;
}
function CalculatorPage() {
  const [cards, setCards] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  const [search, setSearch] = reactExports.useState("");
  const [sortMode, setSortMode] = reactExports.useState("newest");
  reactExports.useEffect(() => {
    loadData();
  }, []);
  async function loadData() {
    try {
      setLoading(true);
      const data = await fetchScratchcards({ sortBy: "issueDate", order: "desc" });
      setCards(data);
    } catch {
      setCards([]);
    } finally {
      setLoading(false);
    }
  }
  const processedCards = reactExports.useMemo(() => {
    let result = cards.filter((c) => !isExpired(c));
    if (search) {
      result = result.filter(
        (c) => c.name.includes(search) || c.gameId.includes(search)
      );
    }
    switch (sortMode) {
      case "hot":
        result.sort((a, b) => {
          const aHot = isHotCard(a, cards) ? 1 : 0;
          const bHot = isHotCard(b, cards) ? 1 : 0;
          if (bHot !== aHot) return bHot - aHot;
          return b.salesRateValue - a.salesRateValue;
        });
        break;
      case "price":
        result.sort((a, b) => b.price - a.price);
        break;
      case "newest":
        result.sort((a, b) => {
          const dateA = parseRocDate(a.issueDate);
          const dateB = parseRocDate(b.issueDate);
          return (dateB?.getTime() || 0) - (dateA?.getTime() || 0);
        });
        break;
      case "winRate":
        result.sort((a, b) => parseWinRate(b.overallWinRate) - parseWinRate(a.overallWinRate));
        break;
    }
    return result;
  }, [cards, search, sortMode]);
  const top10Threshold = reactExports.useMemo(() => {
    const sorted = [...cards].sort((a, b) => b.salesRateValue - a.salesRateValue);
    const idx = Math.max(0, Math.floor(sorted.length * 0.1) - 1);
    return sorted[idx]?.salesRateValue || 100;
  }, [cards]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "home", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      SeoHead,
      {
        title: "殘值計算機 — 刮刮樂每本獎金分佈分析",
        description: "刮刮樂殘值計算機，計算每本刮刮樂的獎金分佈與剩餘殘值，幫助你判斷是否值得繼續刮。",
        path: "/calculator"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "home__hero", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.h1,
        {
          className: "home__title",
          initial: { opacity: 0, y: 30 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.6 },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calculator, { size: 32 }),
            "殘值計算機"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.p,
        {
          className: "home__subtitle",
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.6, delay: 0.1 },
          children: "選擇一款刮刮樂，進入詳情頁使用殘值計算機分析每本獎項分佈"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "home__filters container", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "home__search", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 18 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "搜尋遊戲名稱或編號...",
            value: search,
            onChange: (e) => setSearch(e.target.value)
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "home__sort-tabs", children: SORT_TABS.map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: `sort-tab ${sortMode === tab.key ? "sort-tab--active" : ""}`,
          onClick: () => setSortMode(tab.key),
          children: [
            tab.icon,
            tab.label
          ]
        },
        tab.key
      )) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "home__list-section container", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "home__list-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "home__section-title", children: "選擇款式" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "home__count", children: [
          "共 ",
          processedCards.length,
          " 款"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "home__grid", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "home__loading", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spinner" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "載入中..." })
      ] }) : processedCards.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "home__empty", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { size: 48 }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: cards.length === 0 ? "尚無資料，請先執行後端爬蟲" : "找不到符合條件的刮刮樂" })
      ] }) : processedCards.map((card, index) => {
        const hot = isHotCard(card, cards);
        const isNew = isNewCard(card);
        const soldOut = isSoldOut(card);
        const isTop10 = card.salesRateValue >= top10Threshold && card.salesRateValue > 0;
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.div,
          {
            initial: { opacity: 0, y: 20 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.4, delay: index * 0.03 },
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: `/detail/${card.id}`, className: "card-link", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("article", { className: `scratch-card glass-card ${card.isHighWinRate ? "scratch-card--alert" : ""}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "scratch-card__tags", children: [
                isTop10 && !soldOut && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "scratch-card__tag scratch-card__tag--top", children: "Top 10%" }),
                hot && !soldOut && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "scratch-card__tag scratch-card__tag--hot", children: "🔥 熱門" }),
                isNew && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "scratch-card__tag scratch-card__tag--new", children: "NEW" }),
                soldOut && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "scratch-card__tag scratch-card__tag--sold", children: "已完售" })
              ] }),
              card.isHighWinRate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "scratch-card__badge", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { size: 14 }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "高勝率預警" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "scratch-card__image", children: card.imageUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: card.imageUrl, alt: card.name, loading: "lazy" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "scratch-card__placeholder", children: "🎫" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "scratch-card__info", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "scratch-card__name", children: card.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "scratch-card__price", children: [
                  "$",
                  card.price
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "scratch-card__stats", children: [
                  card.salesRate && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { size: 14 }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "銷售率 ",
                      card.salesRate
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "stat", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Percent, { size: 14 }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "中獎率 ",
                      card.overallWinRate || "-"
                    ] })
                  ] })
                ] }),
                card.maxPrizeAmount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "scratch-card__max-prize", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "scratch-card__max-prize-label", children: "最高獎金" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "scratch-card__max-prize-value", children: card.maxPrizeAmount >= 1e4 ? `${card.maxPrizeAmount / 1e4}萬元` : `${card.maxPrizeAmount.toLocaleString()}元` })
                ] })
              ] })
            ] }) })
          },
          card.id
        );
      }) })
    ] })
  ] });
}
export {
  CalculatorPage as default
};
//# sourceMappingURL=Calculator-DoHYJ8oF.js.map
