import { R as useNavigate, o as useAuth, r as reactExports, j as jsxRuntimeExports } from "./index-CZMt6iFz.js";
function AuthCallback() {
  const navigate = useNavigate();
  const { handleLineCallback, setNickname } = useAuth();
  const [status, setStatus] = reactExports.useState("loading");
  const [error, setError] = reactExports.useState("");
  const [nickname, setNicknameInput] = reactExports.useState("");
  async function processCallback() {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    const state = params.get("state") || "";
    const errorParam = params.get("error");
    if (errorParam) {
      setStatus("error");
      setError("LINE 授權被取消");
      return;
    }
    if (!code) {
      setStatus("error");
      setError("缺少授權碼");
      return;
    }
    try {
      const user = await handleLineCallback(code, state);
      if (user.customNickname === user.displayName) {
        setNicknameInput(user.displayName);
        setStatus("nickname");
        return;
      }
      const redirect = sessionStorage.getItem("line_auth_redirect") || "/";
      sessionStorage.removeItem("line_auth_redirect");
      navigate(redirect, { replace: true });
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "登入失敗");
    }
  }
  reactExports.useEffect(() => {
    processCallback();
  }, []);
  async function handleSaveNickname() {
    if (!nickname.trim()) return;
    try {
      await setNickname(nickname.trim());
      const redirect = sessionStorage.getItem("line_auth_redirect") || "/";
      sessionStorage.removeItem("line_auth_redirect");
      navigate(redirect, { replace: true });
    } catch {
      setError("暱稱儲存失敗");
    }
  }
  if (status === "loading") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "auth-callback", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "auth-callback__card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "auth-callback__spinner" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "正在完成 LINE 登入..." })
    ] }) });
  }
  if (status === "nickname") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "auth-callback", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "auth-callback__card", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: "🎉 歡迎加入刮刮研究室！" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "auth-callback__subtitle", children: "設定您的刮友暱稱" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          className: "auth-callback__input",
          type: "text",
          placeholder: "輸入暱稱...",
          value: nickname,
          onChange: (e) => setNicknameInput(e.target.value),
          maxLength: 50,
          autoFocus: true
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "auth-callback__btn",
          onClick: handleSaveNickname,
          disabled: !nickname.trim(),
          children: "開始探索 🚀"
        }
      )
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "auth-callback", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "auth-callback__card auth-callback__card--error", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: "😥 登入失敗" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        className: "auth-callback__btn",
        onClick: () => navigate("/", { replace: true }),
        children: "返回首頁"
      }
    )
  ] }) });
}
export {
  AuthCallback as default
};
//# sourceMappingURL=AuthCallback-X3K_UUsp.js.map
