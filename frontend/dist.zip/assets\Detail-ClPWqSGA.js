import { c as createLucideIcon, u as useParams, r as reactExports, f as fetchScratchcardDetail, j as jsxRuntimeExports, L as Link, m as motion, S as SeoHead, T as TriangleAlert, P as Percent, a as TrendingUp, b as Trophy, d as Sparkles, C as Calculator, e as fetchNearbyStock, g as recordRetailerExposure } from "./index-CZMt6iFz.js";
import { S as Store, M as MapPin } from "./store-Du8_HzAo.js";
import { N as Navigation } from "./navigation-D42oo081.js";
import { P as Play } from "./play-4Vudt8WI.js";
const __iconNode$4 = [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }]
];
const ArrowLeft = createLucideIcon("arrow-left", __iconNode$4);
const __iconNode$3 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }]
];
const Calendar = createLucideIcon("calendar", __iconNode$3);
const __iconNode$2 = [
  ["line", { x1: "12", x2: "12", y1: "2", y2: "22", key: "7eqyqh" }],
  ["path", { d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6", key: "1b0p4s" }]
];
const DollarSign = createLucideIcon("dollar-sign", __iconNode$2);
const __iconNode$1 = [
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }],
  ["circle", { cx: "6", cy: "12", r: "3", key: "w7nqdw" }],
  ["circle", { cx: "18", cy: "19", r: "3", key: "1xt0gg" }],
  ["line", { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49", key: "47mynk" }],
  ["line", { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49", key: "1n3mei" }]
];
const Share2 = createLucideIcon("share-2", __iconNode$1);
const __iconNode = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
const Target = createLucideIcon("target", __iconNode);
const REVIEW_PLAYLIST_ID = "PLBdL0u1z-6I5Psfqk72nmPKhZ_UESHDK-";
const PRICE_TO_TICKETS_PER_BOOK = {
  100: 100,
  200: 100,
  300: 100,
  500: 50,
  1e3: 25,
  2e3: 19
};
function getDefaultTicketsPerBook(price) {
  return PRICE_TO_TICKETS_PER_BOOK[price] || 100;
}
function Detail() {
  const { id } = useParams();
  const [detail, setDetail] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(true);
  const [ticketsPerBook, setTicketsPerBook] = reactExports.useState(100);
  const [openedCounts, setOpenedCounts] = reactExports.useState({});
  const [openedZero, setOpenedZero] = reactExports.useState(0);
  const [practicalRate, setPracticalRate] = reactExports.useState(60);
  const [nearbyStores, setNearbyStores] = reactExports.useState([]);
  const [nearbyLoading, setNearbyLoading] = reactExports.useState(false);
  const [showNearby, setShowNearby] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (id) {
      loadDetail(Number(id));
    }
  }, [id]);
  async function loadDetail(scratchcardId) {
    try {
      const data = await fetchScratchcardDetail(scratchcardId);
      setDetail(data);
      setTicketsPerBook(getDefaultTicketsPerBook(data.price));
    } catch {
      setDetail(null);
    } finally {
      setLoading(false);
    }
  }
  async function loadNearbyStores() {
    if (!detail) return;
    setNearbyLoading(true);
    setShowNearby(true);
    try {
      let lat;
      let lng;
      if (navigator.geolocation) {
        try {
          const pos = await new Promise(
            (resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5e3 })
          );
          lat = pos.coords.latitude;
          lng = pos.coords.longitude;
        } catch {
        }
      }
      const result = await fetchNearbyStock(detail.id, lat, lng);
      setNearbyStores(result.stores);
      result.stores.forEach((store) => {
        recordRetailerExposure(store.retailerId).catch(() => {
        });
      });
    } catch {
      setNearbyStores([]);
    } finally {
      setNearbyLoading(false);
    }
  }
  const bookAnalysis = reactExports.useMemo(() => {
    if (!detail || !detail.prizes.length || detail.totalIssued === 0 || ticketsPerBook <= 0) return null;
    const totalBooks = detail.totalIssued / ticketsPerBook;
    if (totalBooks <= 0) return null;
    const rows = detail.prizes.map((p, idx) => {
      const perBook = p.totalCount / totalBooks;
      const opened = openedCounts[idx] || 0;
      const remaining = Math.max(0, perBook - opened);
      return {
        prizeName: p.prizeName,
        prizeAmount: p.prizeAmount,
        totalCount: p.totalCount,
        perBook,
        opened,
        remaining
      };
    });
    const prizeTickets = rows.reduce((s, r) => s + r.perBook, 0);
    const zeroTicketsPerBook = Math.max(0, ticketsPerBook - prizeTickets);
    const totalOpened = rows.reduce((s, r) => s + r.opened, 0) + openedZero;
    const remainingValue = rows.reduce((s, r) => s + r.remaining * r.prizeAmount, 0);
    const remainingTickets = ticketsPerBook - totalOpened;
    const costRemaining = remainingTickets * detail.price;
    const totalPrizePerBook = rows.reduce((s, r) => s + r.perBook * r.prizeAmount, 0);
    const totalCostPerBook = ticketsPerBook * detail.price;
    const returnRate = totalCostPerBook > 0 ? Math.round(totalPrizePerBook / totalCostPerBook * 1e3) / 10 : 0;
    const adjustRatio = returnRate > 0 ? practicalRate / returnRate : 1;
    const adjustedRemainingValue = remainingValue * adjustRatio;
    const adjustedTotalPrize = totalPrizePerBook * adjustRatio;
    return {
      totalBooks,
      rows,
      zeroTicketsPerBook,
      remainingValue: adjustedRemainingValue,
      remainingTickets,
      costRemaining,
      totalOpened,
      returnRate,
      adjustedTotalPrize
    };
  }, [detail, ticketsPerBook, openedCounts, openedZero, practicalRate]);
  function updateOpened(idx, value) {
    setOpenedCounts((prev) => ({ ...prev, [idx]: Math.max(0, value) }));
  }
  function calculateROI() {
    if (!detail || detail.totalIssued === 0) return 0;
    const totalPrize = detail.prizes.reduce((sum, p) => sum + p.prizeAmount * p.totalCount, 0);
    const totalCost = detail.totalIssued * detail.price;
    return totalCost > 0 ? Math.round(totalPrize / totalCost * 100 * 10) / 10 : 0;
  }
  function computeWinRate() {
    if (!detail || detail.totalIssued === 0 || detail.prizes.length === 0) return 0;
    const winningTickets = detail.prizes.filter((p) => p.prizeAmount > 0).reduce((sum, p) => sum + p.totalCount, 0);
    return Math.round(winningTickets / detail.totalIssued * 1e4) / 100;
  }
  const roi = calculateROI();
  const winRate = computeWinRate();
  const winRateStr = winRate > 0 ? `${winRate}%` : detail?.overallWinRate || "-";
  function getFeatures() {
    if (!detail) return [];
    const features2 = [];
    if (winRate > 49) {
      features2.push({
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { size: 20 }),
        title: "高勝率",
        desc: `中獎率高達 ${winRateStr}`
      });
    }
    if (roi > 70) {
      features2.push({
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { size: 20 }),
        title: "回本率高",
        desc: `ROI 高於平均${(roi - 65).toFixed(0)}%`
      });
    }
    if (detail.grandPrizeUnclaimed > 0 && detail.grandPrizeCount > 0) {
      const ratio = Math.round(detail.grandPrizeUnclaimed / detail.grandPrizeCount * 100);
      features2.push({
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { size: 20 }),
        title: "頭獎仍在",
        desc: `頭獎剩餘${ratio}%尚未開出`
      });
    }
    if (detail.price <= 200) {
      features2.push({
        icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Target, { size: 20 }),
        title: "小額入門",
        desc: `每張僅 $${detail.price}，適合小資族`
      });
    }
    return features2;
  }
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__loading", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spinner" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "載入中..." })
    ] });
  }
  if (!detail) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__loading", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "找不到該刮刮樂" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", children: "返回首頁" })
    ] });
  }
  const features = getFeatures();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail container", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__top-bar", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "detail__back", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { size: 18 }),
        "返回列表"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "detail__share-btn", onClick: () => navigator.clipboard?.writeText(window.location.href), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Share2, { size: 16 }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.5 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            SeoHead,
            {
              title: `${detail.name} — 中獎率 ${winRateStr} / 最高獎金 ${detail.maxPrize || ""}`,
              description: `${detail.name} 中獎率 ${winRateStr}，最高獎金 ${detail.maxPrize || detail.maxPrizeAmount?.toLocaleString() + "元"}，售價 $${detail.price.toLocaleString()}。查看獎金結構、殘值計算與附近有貨店家。`,
              path: `/detail/${detail.id}`,
              jsonLd: {
                "@context": "https://schema.org",
                "@type": "Product",
                name: detail.name,
                description: `台灣彩券刮刮樂「${detail.name}」，售價 NT$${detail.price}，最高獎金 ${detail.maxPrize || ""}`,
                offers: {
                  "@type": "Offer",
                  price: detail.price,
                  priceCurrency: "TWD",
                  availability: detail.salesRateValue >= 100 ? "https://schema.org/SoldOut" : "https://schema.org/InStock"
                }
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "detail__header glass-card", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__header-content", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__game-id", children: [
                "NO. ",
                detail.gameId
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "detail__title", children: detail.name })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__tags", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "detail__tag detail__tag--price", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { size: 14 }),
                "NT$ ",
                detail.price.toLocaleString()
              ] }),
              detail.isHighWinRate || detail.grandPrizeUnclaimed > 0 && detail.salesRateValue > 85 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "detail__tag detail__tag--alert", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { size: 14, style: { marginRight: "4px" } }),
                detail.isHighWinRate ? "🔥 高勝率預警" : "💰 頭獎仍在"
              ] }) : null
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__metrics", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__metric glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__metric-icon", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Percent, { size: 18 }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "detail__metric-label", children: "中獎率" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "detail__metric-value", children: winRateStr })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__metric glass-card detail__metric--highlight", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__metric-icon", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { size: 18 }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "detail__metric-label", children: "回本率 (ROI)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: "detail__metric-value", children: [
                roi,
                "%"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__metric glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__metric-icon", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { size: 18 }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "detail__metric-label", children: "頭獎金額" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "detail__metric-value", children: detail.maxPrize || `$${detail.maxPrizeAmount?.toLocaleString()}` })
            ] })
          ] }),
          detail.grandPrizeCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__remaining glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__remaining-header", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "detail__remaining-label", children: "即獎剩餘數量" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__remaining-count", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.grandPrizeUnclaimed }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    " / ",
                    detail.grandPrizeCount,
                    " 個"
                  ] })
                ] })
              ] }),
              detail.salesRateValue > 80 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "detail__hot-badge", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { size: 14 }),
                "高銷快訊"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__remaining-bar", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "detail__remaining-fill",
                style: { width: `${detail.grandPrizeCount > 0 ? (detail.grandPrizeCount - detail.grandPrizeUnclaimed) / detail.grandPrizeCount * 100 : 0}%` }
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__remaining-info", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "已開出 ",
                detail.grandPrizeCount - detail.grandPrizeUnclaimed,
                " 個"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                "尚有 ",
                detail.grandPrizeUnclaimed,
                " 個未開出"
              ] })
            ] })
          ] }),
          features.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__features", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "detail__section-title", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { size: 20 }),
              "獨家特色"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__features-grid", children: features.map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__feature-card glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__feature-icon", children: f.icon }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: f.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: f.desc })
            ] }, i)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__section glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "detail__section-title", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { size: 20 }),
              "獎金結構"
            ] }),
            detail.prizes.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__table-wrap", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "detail__table", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "獎項" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "金額" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "總數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "剩餘" })
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: detail.prizes.map((p, i) => {
                  const salesRatio = detail.salesRateValue / 100;
                  const estimatedRemaining = Math.round(p.totalCount * (1 - salesRatio));
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: p.prizeName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "detail__amount", children: p.prizeAmount > 0 ? `$${p.prizeAmount.toLocaleString()}` : "-" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: p.totalCount.toLocaleString() }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "detail__remaining-count-cell", children: estimatedRemaining.toLocaleString() })
                  ] }, i);
                }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "detail__table-note", children: "* 剩餘數量為依銷售率估算，僅供參考" })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "detail__empty", children: "暫無獎金結構資料" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__section glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "detail__section-title", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 20 }),
              "附近有貨店家"
            ] }),
            !showNearby ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { textAlign: "center", padding: "1.5rem" }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: "detail__nearby-btn",
                  onClick: loadNearbyStores,
                  disabled: nearbyLoading,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 18 }),
                    "查詢附近有貨的店家"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { fontSize: "0.8rem", color: "#94a3b8", marginTop: "0.5rem" }, children: "開啟 GPS 可依距離排序" })
            ] }) : nearbyLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { textAlign: "center", padding: "2rem" }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spinner" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "搜尋附近有貨店家中..." })
            ] }) : nearbyStores.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { textAlign: "center", padding: "2rem", color: "#94a3b8" }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 36, style: { opacity: 0.3, marginBottom: "0.5rem" } }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "目前尚無店家回報此款式的庫存" })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__nearby-list", children: nearbyStores.map((store) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__nearby-store", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__nearby-store-info", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: "detail__nearby-store-name", children: [
                  store.retailerName,
                  store.merchantTier === "pro" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "detail__pro-badge", children: "👑 PRO" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "detail__nearby-store-address", children: [
                  "📍 ",
                  store.address
                ] }),
                store.distance !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "detail__nearby-store-distance", children: [
                  "📏 ",
                  store.distance >= 1e3 ? `${(store.distance / 1e3).toFixed(1)} km` : `${store.distance} m`
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__nearby-store-actions", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `detail__nearby-status detail__nearby-status--${store.status === "充足" ? "green" : "yellow"}`, children: [
                  store.status === "充足" ? "🟢" : "🟡",
                  " ",
                  store.status
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "a",
                  {
                    href: `https://www.google.com/maps/search/${encodeURIComponent(store.retailerName + " " + store.address)}`,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "detail__nearby-nav",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Navigation, { size: 14 }),
                      " 導航"
                    ]
                  }
                )
              ] })
            ] }, store.retailerId)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__section glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "detail__section-title", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calculator, { size: 20 }),
              "殘值計算機"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__params", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "calculator__label", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "總發行張數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.totalIssued.toLocaleString() })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "calculator__label", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "每本張數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "number",
                      className: "calculator__input",
                      min: 1,
                      value: ticketsPerBook,
                      onChange: (e) => setTicketsPerBook(Math.max(1, Number(e.target.value)))
                    }
                  )
                ] }),
                bookAnalysis && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "calculator__label", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "發行本數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: Math.round(bookAnalysis.totalBooks).toLocaleString() })
                ] }),
                bookAnalysis && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "calculator__label", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "理論返還率" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: bookAnalysis.returnRate >= 100 ? "text-green" : "text-red", children: [
                    bookAnalysis.returnRate,
                    "%"
                  ] })
                ] })
              ] }),
              bookAnalysis && (() => {
                const sliderMax = bookAnalysis.returnRate;
                const sliderMin = 55;
                const clampedMax = Math.max(sliderMin, sliderMax);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__slider-section", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__slider-header", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "calculator__slider-label", children: "實務返還率調整" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: practicalRate >= 100 ? "text-green" : "text-red", children: [
                      practicalRate,
                      "%"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "range",
                      className: "calculator__slider",
                      min: sliderMin,
                      max: clampedMax,
                      step: 0.5,
                      value: Math.min(practicalRate, clampedMax),
                      onChange: (e) => setPracticalRate(Number(e.target.value))
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__slider-range", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      sliderMin,
                      "%"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                      "理論最高 ",
                      sliderMax,
                      "%"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "calculator__slider-hint", children: "ℹ️ 實際中大獎機率極低，建議以 60% 作為實務參考值" })
                ] });
              })(),
              bookAnalysis && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "calculator__book-table-wrap", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "calculator__book-table", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "獎項" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "金額" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "每本張數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "已開出" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "剩餘" })
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { children: [
                  bookAnalysis.rows.map((row, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: row.prizeName }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "detail__amount", children: row.prizeAmount > 0 ? `$${row.prizeAmount.toLocaleString()}` : "-" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "calculator__per-book", children: row.perBook < 1 ? row.perBook.toFixed(4) : row.perBook.toFixed(1) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        className: "calculator__opened-input",
                        min: 0,
                        value: openedCounts[idx] || 0,
                        onChange: (e) => updateOpened(idx, Number(e.target.value))
                      }
                    ) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: row.remaining > 0 ? "text-green" : "text-muted", children: row.remaining < 1 ? row.remaining.toFixed(1) : row.remaining.toFixed(1) })
                  ] }, idx)),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "calculator__zero-row", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: "未中獎" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: "$0" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: bookAnalysis.zeroTicketsPerBook.toFixed(1) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        className: "calculator__opened-input",
                        min: 0,
                        value: openedZero,
                        onChange: (e) => setOpenedZero(Math.max(0, Number(e.target.value)))
                      }
                    ) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: bookAnalysis.zeroTicketsPerBook - openedZero > 0 ? "text-muted" : "text-muted", children: Math.max(0, bookAnalysis.zeroTicketsPerBook - openedZero).toFixed(1) })
                  ] })
                ] })
              ] }) }),
              bookAnalysis && bookAnalysis.totalOpened > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__results", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__stat", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "已開張數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: bookAnalysis.totalOpened })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__stat", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "剩餘張數" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: bookAnalysis.remainingTickets })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__stat", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "剩餘預估獎金" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: bookAnalysis.remainingValue > 0 ? "text-green" : "text-red", children: [
                    "$",
                    Math.round(bookAnalysis.remainingValue).toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__stat", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "剩餘成本" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                    "$",
                    bookAnalysis.costRemaining.toLocaleString()
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "calculator__stat", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "殘值投報率" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: bookAnalysis.remainingValue >= bookAnalysis.costRemaining ? "text-green" : "text-red", children: bookAnalysis.costRemaining > 0 ? `${Math.round(bookAnalysis.remainingValue / bookAnalysis.costRemaining * 100)}%` : "-" })
                ] })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "detail__section", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "detail__section-title", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { size: 20 }),
              "實況開箱影片"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "detail__video-embed", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "iframe",
              {
                className: "detail__video-iframe",
                src: `https://www.youtube.com/embed/videoseries?list=${REVIEW_PLAYLIST_ID}`,
                title: `${detail.name} 開箱影片`,
                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                allowFullScreen: true
              }
            ) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__dates glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__date-item", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { size: 14 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "上市日" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.issueDate || "-" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__date-item", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { size: 14 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "下市日" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.endDate || "-" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__date-item", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { size: 14 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "兌獎截止" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.redeemDeadline || "-" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "detail__date-item", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DollarSign, { size: 14 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "銷售率" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: detail.salesRate || "-" })
            ] })
          ] })
        ]
      }
    )
  ] });
}
export {
  Detail as default
};
//# sourceMappingURL=Detail-ClPWqSGA.js.map
