import { c as createLucideIcon } from "./index-CZMt6iFz.js";
const __iconNode = [
  [
    "path",
    {
      d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
      key: "10ikf1"
    }
  ]
];
const Play = createLucideIcon("play", __iconNode);
export {
  Play as P
};
//# sourceMappingURL=play-4Vudt8WI.js.map
