import { c as createLucideIcon, r as reactExports, t as fetchRetailers, j as jsxRuntimeExports, m as motion, K as updateBusinessStatus, N as updateRetailerTags, O as createAnnouncement, Q as submitMerchantClaim } from "./index-CZMt6iFz.js";
import { u as useUser, S as Star, C as CircleCheckBig, b as Shield, M as Megaphone, a as Send } from "./useUser-DquVp8dI.js";
import { S as Store, M as MapPin } from "./store-Du8_HzAo.js";
const __iconNode$2 = [
  [
    "path",
    {
      d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
      key: "vktsd0"
    }
  ],
  ["circle", { cx: "7.5", cy: "7.5", r: ".5", fill: "currentColor", key: "kqv944" }]
];
const Tag = createLucideIcon("tag", __iconNode$2);
const __iconNode$1 = [
  ["circle", { cx: "9", cy: "12", r: "3", key: "u3jwor" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
const ToggleLeft = createLucideIcon("toggle-left", __iconNode$1);
const __iconNode = [
  ["circle", { cx: "15", cy: "12", r: "3", key: "1afu0r" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
const ToggleRight = createLucideIcon("toggle-right", __iconNode);
const TAG_CONFIG = [
  { key: "hasAC", label: "❄️ 冷氣", category: "硬體" },
  { key: "hasToilet", label: "🚻 廁所", category: "硬體" },
  { key: "hasSeats", label: "💺 座位", category: "硬體" },
  { key: "hasWifi", label: "📶 Wi-Fi", category: "硬體" },
  { key: "hasAccessibility", label: "♿ 無障礙", category: "硬體" },
  { key: "hasEPay", label: "💳 電子支付", category: "硬體" },
  { key: "hasStrategy", label: "📋 攻略", category: "專業" },
  { key: "hasNumberPick", label: "🔢 挑號", category: "專業" },
  { key: "hasScratchBoard", label: "🪣 刮板", category: "專業" },
  { key: "hasMagnifier", label: "🔍 放大鏡", category: "專業" },
  { key: "hasReadingGlasses", label: "👓 老花眼鏡", category: "專業" },
  { key: "hasNewspaper", label: "📰 明牌報", category: "專業" },
  { key: "hasSportTV", label: "📺 運彩轉播", category: "專業" }
];
const LEVEL_COLORS = [
  "#94a3b8",
  "#6ee7b7",
  "#34d399",
  "#10b981",
  "#f59e0b",
  "#f97316",
  "#ef4444",
  "#dc2626",
  "#a855f7",
  "#d4af37"
];
function MerchantDashboard() {
  const { user } = useUser();
  const [retailers, setRetailers] = reactExports.useState([]);
  const [selectedRetailer, setSelectedRetailer] = reactExports.useState(null);
  const [searchTerm, setSearchTerm] = reactExports.useState("");
  const [step, setStep] = reactExports.useState("search");
  const [tags, setTags] = reactExports.useState({});
  const [announcement, setAnnouncement] = reactExports.useState("");
  const [saving, setSaving] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState("");
  reactExports.useEffect(() => {
    fetchRetailers().then(setRetailers).catch(() => {
    });
  }, []);
  const searchResults = searchTerm.length >= 2 ? retailers.filter(
    (r) => r.name.includes(searchTerm) || r.address.includes(searchTerm)
  ).slice(0, 20) : [];
  function selectRetailer(r) {
    setSelectedRetailer(r);
    setStep("manage");
    const currentTags = {};
    TAG_CONFIG.forEach((t) => {
      currentTags[t.key] = r[t.key] ?? false;
    });
    setTags(currentTags);
    setAnnouncement(r.announcement || "");
  }
  async function toggleStatus() {
    if (!selectedRetailer) return;
    setSaving(true);
    try {
      await updateBusinessStatus(selectedRetailer.id, !selectedRetailer.isActive);
      setSelectedRetailer({ ...selectedRetailer, isActive: !selectedRetailer.isActive });
      showMessage(selectedRetailer.isActive ? "已設為休息中" : "已開始營業");
    } catch {
      showMessage("操作失敗");
    } finally {
      setSaving(false);
    }
  }
  async function saveTags() {
    if (!selectedRetailer) return;
    setSaving(true);
    try {
      await updateRetailerTags(selectedRetailer.id, tags);
      showMessage("設施標籤已更新！");
    } catch {
      showMessage("儲存失敗");
    } finally {
      setSaving(false);
    }
  }
  async function publishAnnouncement() {
    if (!selectedRetailer || !announcement.trim()) return;
    setSaving(true);
    try {
      await createAnnouncement(selectedRetailer.id, announcement);
      showMessage("公告已發佈！");
    } catch {
      showMessage("發佈失敗");
    } finally {
      setSaving(false);
    }
  }
  async function handleClaim() {
    if (!selectedRetailer || !user) return;
    setSaving(true);
    try {
      await submitMerchantClaim({
        retailerId: selectedRetailer.id,
        userId: user.id
      });
      showMessage("認領申請已提交，等待管理員審核");
    } catch {
      showMessage("提交失敗，可能已被認領");
    } finally {
      setSaving(false);
    }
  }
  function showMessage(msg) {
    setMessage(msg);
    setTimeout(() => setMessage(""), 3e3);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant container", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "merchant__hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: { opacity: 0, y: 30 }, animate: { opacity: 1, y: 0 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "merchant__title", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 32 }),
        " 店家管理後台"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "merchant__subtitle", children: "認領你的店家，管理設施標籤與營業狀態" })
    ] }) }),
    user && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "merchant__karma-bar glass-card",
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__karma-badge", style: {
            borderColor: LEVEL_COLORS[user.karmaLevel - 1]
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 16, style: { color: LEVEL_COLORS[user.karmaLevel - 1] } }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Lv.",
              user.karmaLevel
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: user.levelTitle }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "merchant__karma-points", children: [
              user.karmaPoints,
              " 積分"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "merchant__karma-progress", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "merchant__karma-fill", style: {
            width: `${Math.min(100, user.karmaPoints / user.nextLevelPoints * 100)}%`,
            background: LEVEL_COLORS[user.karmaLevel - 1]
          } }) })
        ]
      }
    ),
    message && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "merchant__toast",
        initial: { opacity: 0, y: -10 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { size: 16 }),
          " ",
          message
        ]
      }
    ),
    step === "search" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.section,
      {
        className: "merchant__search-section",
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: "🔍 搜尋你的店家" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "merchant__search-input",
              type: "text",
              placeholder: "輸入店名或地址（至少 2 個字）...",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value)
            }
          ),
          searchResults.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "merchant__search-results", children: searchResults.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "merchant__search-item glass-card",
              onClick: () => selectRetailer(r),
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__search-name", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 16 }),
                  " ",
                  r.name,
                  r.isClaimed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "merchant__claimed-badge", children: "已認領" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__search-address", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 14 }),
                  " ",
                  r.address
                ] })
              ]
            },
            r.id
          )) })
        ]
      }
    ),
    step === "manage" && selectedRetailer && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "merchant__dashboard",
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__store-info glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__store-header", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: selectedRetailer.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "merchant__back-btn", onClick: () => setStep("search"), children: "← 重新選擇" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 14 }),
              " ",
              selectedRetailer.address
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "merchant__store-source", children: [
              selectedRetailer.source === "台灣彩券" ? "🎫" : "⚽",
              " ",
              selectedRetailer.source
            ] })
          ] }),
          !selectedRetailer.isClaimed && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__claim-section glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { size: 18 }),
              " 認領此店家"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "認領後即可管理營業狀態、設施標籤與庫存。認領需管理員審核。" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                className: "merchant__claim-btn",
                onClick: handleClaim,
                disabled: saving || !user,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { size: 16 }),
                  " 提交認領申請"
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__panels", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__panel glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "營業狀態" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: `merchant__status-toggle ${selectedRetailer.isActive ? "merchant__status-toggle--open" : "merchant__status-toggle--closed"}`,
                  onClick: toggleStatus,
                  disabled: saving,
                  children: selectedRetailer.isActive ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ToggleRight, { size: 32 }),
                    " 營業中"
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ToggleLeft, { size: 32 }),
                    " 休息中"
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__panel glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { size: 18 }),
                " 臨時公告"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "textarea",
                {
                  className: "merchant__announcement-input",
                  placeholder: "例：初三不休息、新到 2000 元刮刮樂...",
                  value: announcement,
                  onChange: (e) => setAnnouncement(e.target.value),
                  maxLength: 200
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: "merchant__save-btn",
                  onClick: publishAnnouncement,
                  disabled: saving || !announcement.trim(),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { size: 14 }),
                    " 發佈公告"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__tags-section glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Tag, { size: 18 }),
              " 設施與服務標籤"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "merchant__tags-grid", children: ["硬體", "專業"].map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "merchant__tags-group", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: cat === "硬體" ? "🏪 硬體設施" : "🎯 專業服務" }),
              TAG_CONFIG.filter((t) => t.category === cat).map((t) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "merchant__tag-toggle", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: tags[t.key] || false,
                    onChange: () => setTags({ ...tags, [t.key]: !tags[t.key] })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: t.label })
              ] }, t.key))
            ] }, cat)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                className: "merchant__save-btn",
                onClick: saveTags,
                disabled: saving,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { size: 14 }),
                  " 儲存標籤"
                ]
              }
            )
          ] })
        ]
      }
    )
  ] });
}
export {
  MerchantDashboard as default
};
//# sourceMappingURL=MerchantDashboard-C7PCMd4H.js.map
