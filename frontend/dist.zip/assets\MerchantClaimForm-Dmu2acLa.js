import { j as jsxRuntimeExports, u as useParams, R as useNavigate, W as useSnackbar, o as useAuth, r as reactExports, Y as uploadImage, Q as submitMerchantClaim, t as fetchRetailers } from "./index-CZMt6iFz.js";
import { d as createSvgIcon } from "./createSimplePaletteValueFilter-CdzS8v9F.js";
import { u as useQuery } from "./useQuery-BjRPhU7_.js";
import { B as Box, T as Typography, C as Card } from "./Card-BQoBo3fb.js";
import { T as TextField } from "./TextField-DYBEAZZN.js";
import { A as Alert, B as Button } from "./Button-Bufh6IRY.js";
import { C as CircularProgress } from "./List-ln2SEy6V.js";
const CloudUpload = createSvgIcon(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96M14 13v4h-4v-4H7l5-5 5 5z"
}));
function MerchantClaimForm() {
  const { id } = useParams();
  const retailerId = Number(id);
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useAuth();
  const [contactName, setContactName] = reactExports.useState("");
  const [contactPhone, setContactPhone] = reactExports.useState("");
  const [licenseImage, setLicenseImage] = reactExports.useState(null);
  const [idCardImage, setIdCardImage] = reactExports.useState(null);
  const [submitting, setSubmitting] = reactExports.useState(false);
  const { data: retailers } = useQuery({
    queryKey: ["retailerDetail", retailerId],
    queryFn: () => fetchRetailers({ city: "", source: "" })
    // FIXME: 實作單一尋找 API 或是從外層帶入，為簡化先依賴現有
  });
  const currentStore = retailers?.find((r) => r.id === retailerId);
  if (!user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { sx: { p: 4, pt: { xs: 10, md: 12 }, textAlign: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "h6", children: "請先登入 LINE 再進行認領。" }) });
  }
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!licenseImage || !idCardImage || !contactName || !contactPhone) {
      enqueueSnackbar("請完整填寫聯絡資訊並上傳兩張證件照片", { variant: "warning" });
      return;
    }
    try {
      setSubmitting(true);
      const licenseRes = await uploadImage(licenseImage);
      const idCardRes = await uploadImage(idCardImage);
      await submitMerchantClaim({
        retailerId,
        userId: user.id,
        contactName,
        contactPhone,
        licenseUrl: licenseRes.url,
        idCardUrl: idCardRes.url
      });
      enqueueSnackbar("認領申請已送出！請靜候 1-2 個工作天審核。", { variant: "success" });
      navigate(-1);
    } catch (err) {
      console.error(err);
      enqueueSnackbar(err?.response?.data?.detail || "認領提交失敗，請稍後再試", { variant: "error" });
    } finally {
      setSubmitting(false);
    }
  };
  const handleFileChange = (e, setter) => {
    if (e.target.files && e.target.files.length > 0) {
      setter(e.target.files[0]);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { maxWidth: 600, mx: "auto", p: 2, pt: { xs: 10, md: 12 } }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "h5", fontWeight: 700, mb: 1, children: "商家認領申請" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Typography, { variant: "body2", color: "text.secondary", mb: 3, children: [
      "認領後您將可以維護「",
      currentStore?.name || "此店家",
      "」的精確資訊，包含發布公告、調整設施與即時上報庫存狀況。 目前認領申請為人工審核，請準備清晰之「彩券經銷商證」與「代理人證」照片。"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { sx: { p: 3 }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "subtitle2", fontWeight: 600, mb: 1, children: "基本聯絡資訊" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextField,
        {
          fullWidth: true,
          size: "small",
          label: "真實姓名",
          value: contactName,
          onChange: (e) => setContactName(e.target.value),
          sx: { mb: 2 },
          required: true
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        TextField,
        {
          fullWidth: true,
          size: "small",
          label: "聯絡電話",
          value: contactPhone,
          onChange: (e) => setContactPhone(e.target.value),
          sx: { mb: 3 },
          required: true,
          helperText: "請填寫方便核對資料之電話"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "subtitle2", fontWeight: 600, mb: 1, children: "驗證文件上傳" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Alert, { severity: "info", sx: { mb: 2 }, children: "照片僅做身份查驗之用，我們不會對外公開您的證件資料。" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { display: "flex", flexDirection: "column", gap: 2, mb: 3 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outlined", component: "label", startIcon: /* @__PURE__ */ jsxRuntimeExports.jsx(CloudUpload, {}), children: [
          licenseImage ? licenseImage.name : "上傳「彩券經銷商證」照片",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", hidden: true, accept: "image/jpeg, image/png", onChange: (e) => handleFileChange(e, setLicenseImage) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outlined", component: "label", startIcon: /* @__PURE__ */ jsxRuntimeExports.jsx(CloudUpload, {}), children: [
          idCardImage ? idCardImage.name : "上傳「代理人證」正面照片",
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", hidden: true, accept: "image/jpeg, image/png", onChange: (e) => handleFileChange(e, setIdCardImage) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Button,
        {
          variant: "contained",
          fullWidth: true,
          type: "submit",
          disabled: submitting || !licenseImage || !idCardImage,
          children: submitting ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircularProgress, { size: 24, color: "inherit" }) : "確認並送出申請"
        }
      )
    ] }) }),
    contactName.trim() && contactPhone.trim() && licenseImage && idCardImage ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { mt: 3, pt: 3, borderTop: "1px solid #eee", textAlign: "center" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "body2", color: "text.secondary", mb: 1, children: "需要提供進一步證明文件或遇到問題？" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "contained", color: "success", onClick: () => window.open("https://line.me/R/ti/p/@907dlyso", "_blank"), children: "聯絡官方 LINE 客服" })
    ] }) : null
  ] });
}
export {
  MerchantClaimForm as default
};
//# sourceMappingURL=MerchantClaimForm-Dmu2acLa.js.map
