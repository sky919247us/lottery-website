import { r as reactExports, j as jsxRuntimeExports, U as fetchAuthMe, V as fetchKarmaLogs } from "./index-CZMt6iFz.js";
import { g as generateUtilityClass, a as generateUtilityClasses, u as useDefaultProps, c as clsx, b as composeClasses, s as styled, d as createSvgIcon } from "./createSimplePaletteValueFilter-CdzS8v9F.js";
import { u as useQuery } from "./useQuery-BjRPhU7_.js";
import { B as Box, T as Typography, C as Card } from "./Card-BQoBo3fb.js";
import { L as ListContext, C as CircularProgress, a as List } from "./List-ln2SEy6V.js";
import { A as Avatar, L as LinearProgress, T as Tabs, a as Tab, b as ListItem, c as ListItemText } from "./Tabs-DJKYEoWB.js";
function getListItemAvatarUtilityClass(slot) {
  return generateUtilityClass("MuiListItemAvatar", slot);
}
generateUtilityClasses("MuiListItemAvatar", ["root", "alignItemsFlexStart"]);
const useUtilityClasses = (ownerState) => {
  const {
    alignItems,
    classes
  } = ownerState;
  const slots = {
    root: ["root", alignItems === "flex-start" && "alignItemsFlexStart"]
  };
  return composeClasses(slots, getListItemAvatarUtilityClass, classes);
};
const ListItemAvatarRoot = styled("div", {
  name: "MuiListItemAvatar",
  slot: "Root",
  overridesResolver: (props, styles) => {
    const {
      ownerState
    } = props;
    return [styles.root, ownerState.alignItems === "flex-start" && styles.alignItemsFlexStart];
  }
})({
  minWidth: 56,
  flexShrink: 0,
  variants: [{
    props: {
      alignItems: "flex-start"
    },
    style: {
      marginTop: 8
    }
  }]
});
const ListItemAvatar = /* @__PURE__ */ reactExports.forwardRef(function ListItemAvatar2(inProps, ref) {
  const props = useDefaultProps({
    props: inProps,
    name: "MuiListItemAvatar"
  });
  const {
    className,
    ...other
  } = props;
  const context = reactExports.useContext(ListContext);
  const ownerState = {
    ...props,
    alignItems: context.alignItems
  };
  const classes = useUtilityClasses(ownerState);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemAvatarRoot, {
    className: clsx(classes.root, className),
    ownerState,
    ref,
    ...other
  });
});
const CardGiftcard = createSvgIcon(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2m-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1M9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1m11 15H4v-2h16zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20z"
}));
const LocalMall = createSvgIcon(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M19 6h-2c0-2.76-2.24-5-5-5S7 3.24 7 6H5c-1.1 0-1.99.9-1.99 2L3 20c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2m-7-3c1.66 0 3 1.34 3 3H9c0-1.66 1.34-3 3-3m0 10c-2.76 0-5-2.24-5-5h2c0 1.66 1.34 3 3 3s3-1.34 3-3h2c0 2.76-2.24 5-5 5"
}));
const Star = createSvgIcon(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
}));
const VerifiedUser = createSvgIcon(/* @__PURE__ */ jsxRuntimeExports.jsx("path", {
  d: "M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5zm-2 16-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9z"
}));
const getActionIcon = (action) => {
  switch (action) {
    case "checkin":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(LocalMall, { color: "primary" });
    case "report_inventory":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(CardGiftcard, { color: "secondary" });
    case "rating":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { color: "warning" });
    case "system_award":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(VerifiedUser, { color: "success" });
    default:
      return /* @__PURE__ */ jsxRuntimeExports.jsx(VerifiedUser, { color: "disabled" });
  }
};
function UserProfile() {
  const [tabValue, setTabValue] = reactExports.useState(0);
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ["authMe"],
    queryFn: fetchAuthMe,
    staleTime: 60 * 1e3
    // 快取 1 分鐘
  });
  const { data: logs, isLoading: logsLoading } = useQuery({
    queryKey: ["karmaLogs", user?.id],
    queryFn: () => fetchKarmaLogs(user.id),
    enabled: !!user?.id
  });
  if (userLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { sx: { display: "flex", justifyContent: "center", p: 5 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircularProgress, {}) });
  }
  if (!user) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { sx: { p: 3, textAlign: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { children: "請先登入 LINE 以查看個人中心" }) });
  }
  const progress = user.nextLevelPoints ? Math.min(100, user.karmaPoints / user.nextLevelPoints * 100) : 100;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { maxWidth: 600, mx: "auto", p: 2 }, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "h5", fontWeight: 700, mb: 2, children: "個人積分中心" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { sx: { p: 3, mb: 3, borderRadius: 3, background: "linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)", color: "white" }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { display: "flex", alignItems: "center", gap: 2, mb: 2 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { src: user.pictureUrl, sx: { width: 64, height: 64, border: "2px solid white" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "h6", fontWeight: 700, children: user.customNickname || user.displayName }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Typography, { variant: "body2", sx: { opacity: 0.8 }, children: [
            "目前稱號：Lv.",
            user.karmaLevel,
            " ",
            user.levelTitle
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { mt: 3 }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { display: "flex", justifyContent: "space-between", mb: 1 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Typography, { variant: "body2", children: [
            "積分進度：",
            user.karmaPoints,
            " PTS"
          ] }),
          user.karmaLevel < 10 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Typography, { variant: "body2", children: [
            "目標：",
            user.nextLevelPoints,
            " PTS"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "body2", children: "已達最高等級" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          LinearProgress,
          {
            variant: "determinate",
            value: progress,
            sx: { height: 8, borderRadius: 4, backgroundColor: "rgba(255,255,255,0.3)", "& .MuiLinearProgress-bar": { backgroundColor: "#ffd700" } }
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Tabs, { value: tabValue, onChange: (_, nv) => setTabValue(nv), variant: "fullWidth", sx: { mb: 2 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Tab, { label: "獲取紀錄" }) }),
    tabValue === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { sx: { borderRadius: 2 }, children: logsLoading ? /* @__PURE__ */ jsxRuntimeExports.jsx(Box, { sx: { display: "flex", justifyContent: "center", p: 3 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircularProgress, { size: 24 }) }) : !logs || logs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "body2", color: "text.secondary", align: "center", sx: { p: 4 }, children: "尚無積分獲取紀錄，趕快去打卡或回報庫存吧！" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(List, { children: logs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs(ListItem, { divider: true, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ListItemAvatar, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Avatar, { sx: { bgcolor: "grey.100" }, children: getActionIcon(log.action) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        ListItemText,
        {
          primary: /* @__PURE__ */ jsxRuntimeExports.jsxs(Box, { sx: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Typography, { variant: "body2", fontWeight: 600, children: log.description }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Typography, { variant: "body2", fontWeight: 700, color: log.points > 0 ? "success.main" : "error.main", children: [
              log.points > 0 ? "+" : "",
              log.points
            ] })
          ] }),
          secondary: new Date(log.createdAt).toLocaleString()
        }
      )
    ] }, log.id)) }) })
  ] });
}
export {
  UserProfile as default
};
//# sourceMappingURL=UserProfile-DDR4rJOP.js.map
