import { c as createLucideIcon, r as reactExports, j as jsxRuntimeExports, S as SeoHead, m as motion } from "./index-CZMt6iFz.js";
import { P as Play } from "./play-4Vudt8WI.js";
import { E as ExternalLink, C as ChevronDown, A as AnimatePresence } from "./index-wwLTlieA.js";
const __iconNode = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
];
const Lock = createLucideIcon("lock", __iconNode);
const CHANNEL_URL = "https://www.youtube.com/channel/UCU68swgh6cL3cCauKf5ZJKA";
const PLAYLISTS = [
  {
    id: "new-review",
    emoji: "🔬",
    title: "【新品實測】社長開箱與數據健檢",
    subtitle: "新品實測",
    description: "很多人進彩券行都是憑感覺在挑，但是身為研究室的社長，我們只講數據！每當有新款刮刮樂上市，社長會第一時間對比官方宣傳與真實數據的反差。我們用期望值與賺錢率幫大家健檢，揪出哪些卡水很深，幫助各位研究員避開地雷。",
    playlistId: "PLBdL0u1z-6I5Psfqk72nmPKhZ_UESHDK-",
    tagColor: "#1E8449"
  },
  {
    id: "street-test",
    emoji: "🎪",
    title: "【街頭實戰】對抗機率的實體實驗",
    subtitle: "街頭實戰",
    description: "我們將刮刮樂視為一場對抗機率的實驗！這系列社長會走出研究室，親自在彩券行實測刮卡。究竟實測結果會驗證我們研究室的表格數據，還是社長今天單純出門做公益？話不多說，社長直接刮給你看看最真實的戰況！",
    playlistId: "PLBdL0u1z-6I5hRRkxaZEsPcPZj78no2Jj",
    tagColor: "#F39C12"
  },
  {
    id: "full-book",
    emoji: "📊",
    title: "【包本解密】大樣本刮卡殘酷真相",
    subtitle: "包本解密",
    description: "買一整本到底會不會賺？數據不會騙人！本系列為各位研究員帶來「整本」的大樣本數據分析。社長直接帶你攤開一整本的完整戰績，算給你看整本的地板跟天花板在哪裡，直接揭穿假中獎的陷阱。想看更多大數據實測的朋友，加入我們的研究行列！",
    playlistId: "PLBdL0u1z-6I4Kq6xqPPzREN9B45Vn5otf",
    tagColor: "#D32F2F"
  },
  {
    id: "bingo",
    emoji: "🎱",
    title: "【賓果專區】五分鐘一局的數學課",
    subtitle: "賓果專區",
    description: "除了刮刮樂，BINGO BINGO 同樣需要精密的數據檢驗！這系列社長將利用數學期望值破解電腦彩券的迷思。不管你習慣玩幾星，我們用最理性的態度幫你剖析機率，不鼓勵盲目賭博，強調量力而為。",
    playlistId: "PLBdL0u1z-6I76NNI4LGcwZuZh2rIq1QpE",
    tagColor: "#8E44AD"
  },
  {
    id: "knowledge",
    emoji: "📚",
    title: "【研究員必修】刮刮樂防雷與機率科普",
    subtitle: "研究員必修",
    description: "想加入研究室，這份終極防雷指南必看！這系列專門講解核心的數據定義，帶你搞懂「期望值」、「回本率」與「賺錢率」到底差在哪。社長教你怎麼看懂背後的數學邏輯，建立將刮刮樂視為娛樂而非投資的正確觀念。",
    playlistId: "PLBdL0u1z-6I4ZX4XHaTaZVugQbMlYfKhb",
    tagColor: "#0B192C"
  },
  {
    id: "member",
    emoji: "🔒",
    title: "【刮刮研究室】會員限定：機密數據庫 & 審計原始檔",
    subtitle: "會員限定",
    description: "這裡是刮刮研究室的「軍火庫」。存放所有未經剪輯的實測過程、獨家審計報告，以及公開頻道看不到的殘酷真相。這裡沒有特效，沒有綜藝濾鏡，只有最冰冷的數據與機率。",
    playlistId: "PLBdL0u1z-6I52MSrlCT0UZqz7iUwatqLH",
    isMemberOnly: true,
    tagColor: "#5A6268"
  }
];
function Videos() {
  const [expandedId, setExpandedId] = reactExports.useState(PLAYLISTS[0].id);
  const [playingId, setPlayingId] = reactExports.useState(null);
  function toggleExpand(id) {
    setExpandedId((prev) => prev === id ? null : id);
  }
  function handlePlay(playlist) {
    if (playlist.isMemberOnly) {
      window.open(`${CHANNEL_URL}/join`, "_blank");
      return;
    }
    setPlayingId(playlist.id);
    setExpandedId(playlist.id);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "videos container", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      SeoHead,
      {
        title: "影片列表 — 刮刮研究室開箱與數據分析",
        description: "刮刮研究室精選影片，新品實測、街頭實戰、包本解密、賓果專區、機率科普，用數據破解刮刮樂。",
        path: "/videos"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "videos__page-header",
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "videos__page-title", children: "📺 影片列表" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "videos__page-desc", children: "刮刮研究室精選影片，依主題分類瀏覽" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: CHANNEL_URL,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "videos__yt-btn",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { size: 16 }),
                "前往 YouTube 頻道",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { size: 14 })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "videos__playlists", children: PLAYLISTS.map((pl, index) => {
      const isExpanded = expandedId === pl.id;
      const isPlaying = playingId === pl.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          className: `playlist-card ${isExpanded ? "playlist-card--expanded" : ""} ${pl.isMemberOnly ? "playlist-card--member" : ""}`,
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: index * 0.06 },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                className: "playlist-card__header",
                onClick: () => toggleExpand(pl.id),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "playlist-card__tag", style: { background: pl.tagColor }, children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: pl.emoji }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: pl.subtitle })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "playlist-card__title", children: pl.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    ChevronDown,
                    {
                      size: 20,
                      className: `playlist-card__chevron ${isExpanded ? "playlist-card__chevron--open" : ""}`
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: isExpanded && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                className: "playlist-card__body",
                initial: { height: 0, opacity: 0 },
                animate: { height: "auto", opacity: 1 },
                exit: { height: 0, opacity: 0 },
                transition: { duration: 0.3 },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "playlist-card__desc", children: pl.description }),
                  pl.isMemberOnly && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "playlist-card__member-notice", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { size: 16 }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "本區內容僅供「研究員」級別以上會員觀看，請勿外流。" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "playlist-card__actions", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        className: `playlist-card__play-btn ${pl.isMemberOnly ? "playlist-card__play-btn--member" : ""}`,
                        onClick: () => handlePlay(pl),
                        children: pl.isMemberOnly ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { size: 16 }),
                          "加入會員觀看"
                        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { size: 16 }),
                          isPlaying ? "正在播放" : "播放此清單"
                        ] })
                      }
                    ),
                    !pl.isMemberOnly && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "a",
                      {
                        href: `https://www.youtube.com/playlist?list=${pl.playlistId}`,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "playlist-card__yt-link",
                        children: [
                          "在 YouTube 觀看",
                          /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { size: 14 })
                        ]
                      }
                    )
                  ] }),
                  isPlaying && !pl.isMemberOnly && /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.div,
                    {
                      className: "playlist-card__player",
                      initial: { opacity: 0, y: 10 },
                      animate: { opacity: 1, y: 0 },
                      transition: { duration: 0.3 },
                      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "iframe",
                        {
                          className: "playlist-card__iframe",
                          src: `https://www.youtube.com/embed/videoseries?list=${pl.playlistId}`,
                          title: pl.title,
                          allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                          allowFullScreen: true
                        }
                      )
                    }
                  )
                ]
              }
            ) })
          ]
        },
        pl.id
      );
    }) })
  ] });
}
export {
  Videos as default
};
//# sourceMappingURL=Videos-CT8qIy3n.js.map
