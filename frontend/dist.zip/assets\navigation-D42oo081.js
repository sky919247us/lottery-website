import { c as createLucideIcon } from "./index-CZMt6iFz.js";
const __iconNode = [
  ["polygon", { points: "3 11 22 2 13 21 11 13 3 11", key: "1ltx0t" }]
];
const Navigation = createLucideIcon("navigation", __iconNode);
export {
  Navigation as N
};
//# sourceMappingURL=navigation-D42oo081.js.map
