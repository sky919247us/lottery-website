import { c as createLucideIcon, r as reactExports, l as fetchRatingSummary, j as jsxRuntimeExports, n as fetchRetailerRatings, o as useAuth, X, p as submitRating, q as recordRetailerClick, t as fetchRetailers, v as fetchCheckins, w as fetchFestivalStatus, x as fetchHeatmap, y as fetchMerchantOfficialInventory, z as fetchInventory, S as SeoHead, m as motion, F as Flame, i as Search, b as Trophy, L as Link, s as searchScratchcardsPublic, A as createCheckin, B as reportInventory } from "./index-CZMt6iFz.js";
import { c as createOverlayComponent, l as leafletSrcExports, a as createElementObject, b as createPathComponent, L as L$1, e as extendContext, u as useMap, M as MapContainer, T as TileLayer, d as Marker } from "./TileLayer-yiJKB963.js";
import { C as CircleCheckBig, S as Star, u as useUser, a as Send, b as Shield, M as Megaphone } from "./useUser-DquVp8dI.js";
import { M as MapPin, S as Store } from "./store-Du8_HzAo.js";
import { A as AnimatePresence, C as ChevronDown, E as ExternalLink } from "./index-wwLTlieA.js";
import { N as Navigation } from "./navigation-D42oo081.js";
const __iconNode$5 = [
  [
    "path",
    {
      d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
      key: "sc7q7i"
    }
  ]
];
const Funnel = createLucideIcon("funnel", __iconNode$5);
const __iconNode$4 = [
  ["path", { d: "M3 5h.01", key: "18ugdj" }],
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M3 19h.01", key: "noohij" }],
  ["path", { d: "M8 5h13", key: "1pao27" }],
  ["path", { d: "M8 12h13", key: "1za7za" }],
  ["path", { d: "M8 19h13", key: "m83p4d" }]
];
const List = createLucideIcon("list", __iconNode$4);
const __iconNode$3 = [
  [
    "path",
    {
      d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
      key: "169xi5"
    }
  ],
  ["path", { d: "M15 5.764v15", key: "1pn4in" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
];
const Map$1 = createLucideIcon("map", __iconNode$3);
const __iconNode$2 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ]
];
const MessageCircle = createLucideIcon("message-circle", __iconNode$2);
const __iconNode$1 = [
  [
    "path",
    {
      d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
      key: "1a0edw"
    }
  ],
  ["path", { d: "M12 22V12", key: "d0xqtd" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }]
];
const Package = createLucideIcon("package", __iconNode$1);
const __iconNode = [
  ["path", { d: "M5.8 11.3 2 22l10.7-3.79", key: "gwxi1d" }],
  ["path", { d: "M4 3h.01", key: "1vcuye" }],
  ["path", { d: "M22 8h.01", key: "1mrtc2" }],
  ["path", { d: "M15 2h.01", key: "1cjtqr" }],
  ["path", { d: "M22 20h.01", key: "1mrys2" }],
  [
    "path",
    {
      d: "m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10",
      key: "hbicv8"
    }
  ],
  [
    "path",
    { d: "m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17", key: "1i94pl" }
  ],
  ["path", { d: "m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7", key: "1cofks" }],
  [
    "path",
    {
      d: "M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z",
      key: "4kbmks"
    }
  ]
];
const PartyPopper = createLucideIcon("party-popper", __iconNode);
const Popup = createOverlayComponent(function createPopup(props, context) {
  const popup = new leafletSrcExports.Popup(props, context.overlayContainer);
  return createElementObject(popup, context);
}, function usePopupLifecycle(element, context, { position }, setOpen) {
  reactExports.useEffect(function addPopup() {
    const { instance } = element;
    function onPopupOpen(event) {
      if (event.popup === instance) {
        instance.update();
        setOpen(true);
      }
    }
    function onPopupClose(event) {
      if (event.popup === instance) {
        setOpen(false);
      }
    }
    context.map.on({
      popupopen: onPopupOpen,
      popupclose: onPopupClose
    });
    if (context.overlayContainer == null) {
      if (position != null) {
        instance.setLatLng(position);
      }
      instance.openOn(context.map);
    } else {
      context.overlayContainer.bindPopup(instance);
    }
    return function removePopup() {
      context.map.off({
        popupopen: onPopupOpen,
        popupclose: onPopupClose
      });
      context.overlayContainer?.unbindPopup();
      context.map.removeLayer(instance);
    };
  }, [
    element,
    context,
    setOpen,
    position
  ]);
});
var leaflet_markerclusterSrc$1 = { exports: {} };
var leaflet_markerclusterSrc = leaflet_markerclusterSrc$1.exports;
var hasRequiredLeaflet_markerclusterSrc;
function requireLeaflet_markerclusterSrc() {
  if (hasRequiredLeaflet_markerclusterSrc) return leaflet_markerclusterSrc$1.exports;
  hasRequiredLeaflet_markerclusterSrc = 1;
  (function(module, exports$1) {
    (function(global, factory) {
      factory(exports$1);
    })(leaflet_markerclusterSrc, function(exports$12) {
      var MarkerClusterGroup2 = L.MarkerClusterGroup = L.FeatureGroup.extend({
        options: {
          maxClusterRadius: 80,
          //A cluster will cover at most this many pixels from its center
          iconCreateFunction: null,
          clusterPane: L.Marker.prototype.options.pane,
          spiderfyOnEveryZoom: false,
          spiderfyOnMaxZoom: true,
          showCoverageOnHover: true,
          zoomToBoundsOnClick: true,
          singleMarkerMode: false,
          disableClusteringAtZoom: null,
          // Setting this to false prevents the removal of any clusters outside of the viewpoint, which
          // is the default behaviour for performance reasons.
          removeOutsideVisibleBounds: true,
          // Set to false to disable all animations (zoom and spiderfy).
          // If false, option animateAddingMarkers below has no effect.
          // If L.DomUtil.TRANSITION is falsy, this option has no effect.
          animate: true,
          //Whether to animate adding markers after adding the MarkerClusterGroup to the map
          // If you are adding individual markers set to true, if adding bulk markers leave false for massive performance gains.
          animateAddingMarkers: false,
          // Make it possible to provide custom function to calculate spiderfy shape positions
          spiderfyShapePositions: null,
          //Increase to increase the distance away that spiderfied markers appear from the center
          spiderfyDistanceMultiplier: 1,
          // Make it possible to specify a polyline options on a spider leg
          spiderLegPolylineOptions: { weight: 1.5, color: "#222", opacity: 0.5 },
          // When bulk adding layers, adds markers in chunks. Means addLayers may not add all the layers in the call, others will be loaded during setTimeouts
          chunkedLoading: false,
          chunkInterval: 200,
          // process markers for a maximum of ~ n milliseconds (then trigger the chunkProgress callback)
          chunkDelay: 50,
          // at the end of each interval, give n milliseconds back to system/browser
          chunkProgress: null,
          // progress callback: function(processed, total, elapsed) (e.g. for a progress indicator)
          //Options to pass to the L.Polygon constructor
          polygonOptions: {}
        },
        initialize: function(options) {
          L.Util.setOptions(this, options);
          if (!this.options.iconCreateFunction) {
            this.options.iconCreateFunction = this._defaultIconCreateFunction;
          }
          this._featureGroup = L.featureGroup();
          this._featureGroup.addEventParent(this);
          this._nonPointGroup = L.featureGroup();
          this._nonPointGroup.addEventParent(this);
          this._inZoomAnimation = 0;
          this._needsClustering = [];
          this._needsRemoving = [];
          this._currentShownBounds = null;
          this._queue = [];
          this._childMarkerEventHandlers = {
            "dragstart": this._childMarkerDragStart,
            "move": this._childMarkerMoved,
            "dragend": this._childMarkerDragEnd
          };
          var animate = L.DomUtil.TRANSITION && this.options.animate;
          L.extend(this, animate ? this._withAnimation : this._noAnimation);
          this._markerCluster = animate ? L.MarkerCluster : L.MarkerClusterNonAnimated;
        },
        addLayer: function(layer) {
          if (layer instanceof L.LayerGroup) {
            return this.addLayers([layer]);
          }
          if (!layer.getLatLng) {
            this._nonPointGroup.addLayer(layer);
            this.fire("layeradd", { layer });
            return this;
          }
          if (!this._map) {
            this._needsClustering.push(layer);
            this.fire("layeradd", { layer });
            return this;
          }
          if (this.hasLayer(layer)) {
            return this;
          }
          if (this._unspiderfy) {
            this._unspiderfy();
          }
          this._addLayer(layer, this._maxZoom);
          this.fire("layeradd", { layer });
          this._topClusterLevel._recalculateBounds();
          this._refreshClustersIcons();
          var visibleLayer = layer, currentZoom = this._zoom;
          if (layer.__parent) {
            while (visibleLayer.__parent._zoom >= currentZoom) {
              visibleLayer = visibleLayer.__parent;
            }
          }
          if (this._currentShownBounds.contains(visibleLayer.getLatLng())) {
            if (this.options.animateAddingMarkers) {
              this._animationAddLayer(layer, visibleLayer);
            } else {
              this._animationAddLayerNonAnimated(layer, visibleLayer);
            }
          }
          return this;
        },
        removeLayer: function(layer) {
          if (layer instanceof L.LayerGroup) {
            return this.removeLayers([layer]);
          }
          if (!layer.getLatLng) {
            this._nonPointGroup.removeLayer(layer);
            this.fire("layerremove", { layer });
            return this;
          }
          if (!this._map) {
            if (!this._arraySplice(this._needsClustering, layer) && this.hasLayer(layer)) {
              this._needsRemoving.push({ layer, latlng: layer._latlng });
            }
            this.fire("layerremove", { layer });
            return this;
          }
          if (!layer.__parent) {
            return this;
          }
          if (this._unspiderfy) {
            this._unspiderfy();
            this._unspiderfyLayer(layer);
          }
          this._removeLayer(layer, true);
          this.fire("layerremove", { layer });
          this._topClusterLevel._recalculateBounds();
          this._refreshClustersIcons();
          layer.off(this._childMarkerEventHandlers, this);
          if (this._featureGroup.hasLayer(layer)) {
            this._featureGroup.removeLayer(layer);
            if (layer.clusterShow) {
              layer.clusterShow();
            }
          }
          return this;
        },
        //Takes an array of markers and adds them in bulk
        addLayers: function(layersArray, skipLayerAddEvent) {
          if (!L.Util.isArray(layersArray)) {
            return this.addLayer(layersArray);
          }
          var fg = this._featureGroup, npg = this._nonPointGroup, chunked = this.options.chunkedLoading, chunkInterval = this.options.chunkInterval, chunkProgress = this.options.chunkProgress, l = layersArray.length, offset = 0, originalArray = true, m;
          if (this._map) {
            var started = (/* @__PURE__ */ new Date()).getTime();
            var process = L.bind(function() {
              var start = (/* @__PURE__ */ new Date()).getTime();
              if (this._map && this._unspiderfy) {
                this._unspiderfy();
              }
              for (; offset < l; offset++) {
                if (chunked && offset % 200 === 0) {
                  var elapsed = (/* @__PURE__ */ new Date()).getTime() - start;
                  if (elapsed > chunkInterval) {
                    break;
                  }
                }
                m = layersArray[offset];
                if (m instanceof L.LayerGroup) {
                  if (originalArray) {
                    layersArray = layersArray.slice();
                    originalArray = false;
                  }
                  this._extractNonGroupLayers(m, layersArray);
                  l = layersArray.length;
                  continue;
                }
                if (!m.getLatLng) {
                  npg.addLayer(m);
                  if (!skipLayerAddEvent) {
                    this.fire("layeradd", { layer: m });
                  }
                  continue;
                }
                if (this.hasLayer(m)) {
                  continue;
                }
                this._addLayer(m, this._maxZoom);
                if (!skipLayerAddEvent) {
                  this.fire("layeradd", { layer: m });
                }
                if (m.__parent) {
                  if (m.__parent.getChildCount() === 2) {
                    var markers = m.__parent.getAllChildMarkers(), otherMarker = markers[0] === m ? markers[1] : markers[0];
                    fg.removeLayer(otherMarker);
                  }
                }
              }
              if (chunkProgress) {
                chunkProgress(offset, l, (/* @__PURE__ */ new Date()).getTime() - started);
              }
              if (offset === l) {
                this._topClusterLevel._recalculateBounds();
                this._refreshClustersIcons();
                this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds);
              } else {
                setTimeout(process, this.options.chunkDelay);
              }
            }, this);
            process();
          } else {
            var needsClustering = this._needsClustering;
            for (; offset < l; offset++) {
              m = layersArray[offset];
              if (m instanceof L.LayerGroup) {
                if (originalArray) {
                  layersArray = layersArray.slice();
                  originalArray = false;
                }
                this._extractNonGroupLayers(m, layersArray);
                l = layersArray.length;
                continue;
              }
              if (!m.getLatLng) {
                npg.addLayer(m);
                continue;
              }
              if (this.hasLayer(m)) {
                continue;
              }
              needsClustering.push(m);
            }
          }
          return this;
        },
        //Takes an array of markers and removes them in bulk
        removeLayers: function(layersArray) {
          var i, m, l = layersArray.length, fg = this._featureGroup, npg = this._nonPointGroup, originalArray = true;
          if (!this._map) {
            for (i = 0; i < l; i++) {
              m = layersArray[i];
              if (m instanceof L.LayerGroup) {
                if (originalArray) {
                  layersArray = layersArray.slice();
                  originalArray = false;
                }
                this._extractNonGroupLayers(m, layersArray);
                l = layersArray.length;
                continue;
              }
              this._arraySplice(this._needsClustering, m);
              npg.removeLayer(m);
              if (this.hasLayer(m)) {
                this._needsRemoving.push({ layer: m, latlng: m._latlng });
              }
              this.fire("layerremove", { layer: m });
            }
            return this;
          }
          if (this._unspiderfy) {
            this._unspiderfy();
            var layersArray2 = layersArray.slice(), l2 = l;
            for (i = 0; i < l2; i++) {
              m = layersArray2[i];
              if (m instanceof L.LayerGroup) {
                this._extractNonGroupLayers(m, layersArray2);
                l2 = layersArray2.length;
                continue;
              }
              this._unspiderfyLayer(m);
            }
          }
          for (i = 0; i < l; i++) {
            m = layersArray[i];
            if (m instanceof L.LayerGroup) {
              if (originalArray) {
                layersArray = layersArray.slice();
                originalArray = false;
              }
              this._extractNonGroupLayers(m, layersArray);
              l = layersArray.length;
              continue;
            }
            if (!m.__parent) {
              npg.removeLayer(m);
              this.fire("layerremove", { layer: m });
              continue;
            }
            this._removeLayer(m, true, true);
            this.fire("layerremove", { layer: m });
            if (fg.hasLayer(m)) {
              fg.removeLayer(m);
              if (m.clusterShow) {
                m.clusterShow();
              }
            }
          }
          this._topClusterLevel._recalculateBounds();
          this._refreshClustersIcons();
          this._topClusterLevel._recursivelyAddChildrenToMap(null, this._zoom, this._currentShownBounds);
          return this;
        },
        //Removes all layers from the MarkerClusterGroup
        clearLayers: function() {
          if (!this._map) {
            this._needsClustering = [];
            this._needsRemoving = [];
            delete this._gridClusters;
            delete this._gridUnclustered;
          }
          if (this._noanimationUnspiderfy) {
            this._noanimationUnspiderfy();
          }
          this._featureGroup.clearLayers();
          this._nonPointGroup.clearLayers();
          this.eachLayer(function(marker) {
            marker.off(this._childMarkerEventHandlers, this);
            delete marker.__parent;
          }, this);
          if (this._map) {
            this._generateInitialClusters();
          }
          return this;
        },
        //Override FeatureGroup.getBounds as it doesn't work
        getBounds: function() {
          var bounds = new L.LatLngBounds();
          if (this._topClusterLevel) {
            bounds.extend(this._topClusterLevel._bounds);
          }
          for (var i = this._needsClustering.length - 1; i >= 0; i--) {
            bounds.extend(this._needsClustering[i].getLatLng());
          }
          bounds.extend(this._nonPointGroup.getBounds());
          return bounds;
        },
        //Overrides LayerGroup.eachLayer
        eachLayer: function(method, context) {
          var markers = this._needsClustering.slice(), needsRemoving = this._needsRemoving, thisNeedsRemoving, i, j;
          if (this._topClusterLevel) {
            this._topClusterLevel.getAllChildMarkers(markers);
          }
          for (i = markers.length - 1; i >= 0; i--) {
            thisNeedsRemoving = true;
            for (j = needsRemoving.length - 1; j >= 0; j--) {
              if (needsRemoving[j].layer === markers[i]) {
                thisNeedsRemoving = false;
                break;
              }
            }
            if (thisNeedsRemoving) {
              method.call(context, markers[i]);
            }
          }
          this._nonPointGroup.eachLayer(method, context);
        },
        //Overrides LayerGroup.getLayers
        getLayers: function() {
          var layers = [];
          this.eachLayer(function(l) {
            layers.push(l);
          });
          return layers;
        },
        //Overrides LayerGroup.getLayer, WARNING: Really bad performance
        getLayer: function(id) {
          var result = null;
          id = parseInt(id, 10);
          this.eachLayer(function(l) {
            if (L.stamp(l) === id) {
              result = l;
            }
          });
          return result;
        },
        //Returns true if the given layer is in this MarkerClusterGroup
        hasLayer: function(layer) {
          if (!layer) {
            return false;
          }
          var i, anArray = this._needsClustering;
          for (i = anArray.length - 1; i >= 0; i--) {
            if (anArray[i] === layer) {
              return true;
            }
          }
          anArray = this._needsRemoving;
          for (i = anArray.length - 1; i >= 0; i--) {
            if (anArray[i].layer === layer) {
              return false;
            }
          }
          return !!(layer.__parent && layer.__parent._group === this) || this._nonPointGroup.hasLayer(layer);
        },
        //Zoom down to show the given layer (spiderfying if necessary) then calls the callback
        zoomToShowLayer: function(layer, callback) {
          var map = this._map;
          if (typeof callback !== "function") {
            callback = function() {
            };
          }
          var showMarker = function() {
            if ((map.hasLayer(layer) || map.hasLayer(layer.__parent)) && !this._inZoomAnimation) {
              this._map.off("moveend", showMarker, this);
              this.off("animationend", showMarker, this);
              if (map.hasLayer(layer)) {
                callback();
              } else if (layer.__parent._icon) {
                this.once("spiderfied", callback, this);
                layer.__parent.spiderfy();
              }
            }
          };
          if (layer._icon && this._map.getBounds().contains(layer.getLatLng())) {
            callback();
          } else if (layer.__parent._zoom < Math.round(this._map._zoom)) {
            this._map.on("moveend", showMarker, this);
            this._map.panTo(layer.getLatLng());
          } else {
            this._map.on("moveend", showMarker, this);
            this.on("animationend", showMarker, this);
            layer.__parent.zoomToBounds();
          }
        },
        //Overrides FeatureGroup.onAdd
        onAdd: function(map) {
          this._map = map;
          var i, l, layer;
          if (!isFinite(this._map.getMaxZoom())) {
            throw "Map has no maxZoom specified";
          }
          this._featureGroup.addTo(map);
          this._nonPointGroup.addTo(map);
          if (!this._gridClusters) {
            this._generateInitialClusters();
          }
          this._maxLat = map.options.crs.projection.MAX_LATITUDE;
          for (i = 0, l = this._needsRemoving.length; i < l; i++) {
            layer = this._needsRemoving[i];
            layer.newlatlng = layer.layer._latlng;
            layer.layer._latlng = layer.latlng;
          }
          for (i = 0, l = this._needsRemoving.length; i < l; i++) {
            layer = this._needsRemoving[i];
            this._removeLayer(layer.layer, true);
            layer.layer._latlng = layer.newlatlng;
          }
          this._needsRemoving = [];
          this._zoom = Math.round(this._map._zoom);
          this._currentShownBounds = this._getExpandedVisibleBounds();
          this._map.on("zoomend", this._zoomEnd, this);
          this._map.on("moveend", this._moveEnd, this);
          if (this._spiderfierOnAdd) {
            this._spiderfierOnAdd();
          }
          this._bindEvents();
          l = this._needsClustering;
          this._needsClustering = [];
          this.addLayers(l, true);
        },
        //Overrides FeatureGroup.onRemove
        onRemove: function(map) {
          map.off("zoomend", this._zoomEnd, this);
          map.off("moveend", this._moveEnd, this);
          this._unbindEvents();
          this._map._mapPane.className = this._map._mapPane.className.replace(" leaflet-cluster-anim", "");
          if (this._spiderfierOnRemove) {
            this._spiderfierOnRemove();
          }
          delete this._maxLat;
          this._hideCoverage();
          this._featureGroup.remove();
          this._nonPointGroup.remove();
          this._featureGroup.clearLayers();
          this._map = null;
        },
        getVisibleParent: function(marker) {
          var vMarker = marker;
          while (vMarker && !vMarker._icon) {
            vMarker = vMarker.__parent;
          }
          return vMarker || null;
        },
        //Remove the given object from the given array
        _arraySplice: function(anArray, obj) {
          for (var i = anArray.length - 1; i >= 0; i--) {
            if (anArray[i] === obj) {
              anArray.splice(i, 1);
              return true;
            }
          }
        },
        /**
         * Removes a marker from all _gridUnclustered zoom levels, starting at the supplied zoom.
         * @param marker to be removed from _gridUnclustered.
         * @param z integer bottom start zoom level (included)
         * @private
         */
        _removeFromGridUnclustered: function(marker, z) {
          var map = this._map, gridUnclustered = this._gridUnclustered, minZoom = Math.floor(this._map.getMinZoom());
          for (; z >= minZoom; z--) {
            if (!gridUnclustered[z].removeObject(marker, map.project(marker.getLatLng(), z))) {
              break;
            }
          }
        },
        _childMarkerDragStart: function(e) {
          e.target.__dragStart = e.target._latlng;
        },
        _childMarkerMoved: function(e) {
          if (!this._ignoreMove && !e.target.__dragStart) {
            var isPopupOpen = e.target._popup && e.target._popup.isOpen();
            this._moveChild(e.target, e.oldLatLng, e.latlng);
            if (isPopupOpen) {
              e.target.openPopup();
            }
          }
        },
        _moveChild: function(layer, from, to) {
          layer._latlng = from;
          this.removeLayer(layer);
          layer._latlng = to;
          this.addLayer(layer);
        },
        _childMarkerDragEnd: function(e) {
          var dragStart = e.target.__dragStart;
          delete e.target.__dragStart;
          if (dragStart) {
            this._moveChild(e.target, dragStart, e.target._latlng);
          }
        },
        //Internal function for removing a marker from everything.
        //dontUpdateMap: set to true if you will handle updating the map manually (for bulk functions)
        _removeLayer: function(marker, removeFromDistanceGrid, dontUpdateMap) {
          var gridClusters = this._gridClusters, gridUnclustered = this._gridUnclustered, fg = this._featureGroup, map = this._map, minZoom = Math.floor(this._map.getMinZoom());
          if (removeFromDistanceGrid) {
            this._removeFromGridUnclustered(marker, this._maxZoom);
          }
          var cluster = marker.__parent, markers = cluster._markers, otherMarker;
          this._arraySplice(markers, marker);
          while (cluster) {
            cluster._childCount--;
            cluster._boundsNeedUpdate = true;
            if (cluster._zoom < minZoom) {
              break;
            } else if (removeFromDistanceGrid && cluster._childCount <= 1) {
              otherMarker = cluster._markers[0] === marker ? cluster._markers[1] : cluster._markers[0];
              gridClusters[cluster._zoom].removeObject(cluster, map.project(cluster._cLatLng, cluster._zoom));
              gridUnclustered[cluster._zoom].addObject(otherMarker, map.project(otherMarker.getLatLng(), cluster._zoom));
              this._arraySplice(cluster.__parent._childClusters, cluster);
              cluster.__parent._markers.push(otherMarker);
              otherMarker.__parent = cluster.__parent;
              if (cluster._icon) {
                fg.removeLayer(cluster);
                if (!dontUpdateMap) {
                  fg.addLayer(otherMarker);
                }
              }
            } else {
              cluster._iconNeedsUpdate = true;
            }
            cluster = cluster.__parent;
          }
          delete marker.__parent;
        },
        _isOrIsParent: function(el, oel) {
          while (oel) {
            if (el === oel) {
              return true;
            }
            oel = oel.parentNode;
          }
          return false;
        },
        //Override L.Evented.fire
        fire: function(type, data, propagate) {
          if (data && data.layer instanceof L.MarkerCluster) {
            if (data.originalEvent && this._isOrIsParent(data.layer._icon, data.originalEvent.relatedTarget)) {
              return;
            }
            type = "cluster" + type;
          }
          L.FeatureGroup.prototype.fire.call(this, type, data, propagate);
        },
        //Override L.Evented.listens
        listens: function(type, propagate) {
          return L.FeatureGroup.prototype.listens.call(this, type, propagate) || L.FeatureGroup.prototype.listens.call(this, "cluster" + type, propagate);
        },
        //Default functionality
        _defaultIconCreateFunction: function(cluster) {
          var childCount = cluster.getChildCount();
          var c = " marker-cluster-";
          if (childCount < 10) {
            c += "small";
          } else if (childCount < 100) {
            c += "medium";
          } else {
            c += "large";
          }
          return new L.DivIcon({ html: "<div><span>" + childCount + "</span></div>", className: "marker-cluster" + c, iconSize: new L.Point(40, 40) });
        },
        _bindEvents: function() {
          var map = this._map, spiderfyOnMaxZoom = this.options.spiderfyOnMaxZoom, showCoverageOnHover = this.options.showCoverageOnHover, zoomToBoundsOnClick = this.options.zoomToBoundsOnClick, spiderfyOnEveryZoom = this.options.spiderfyOnEveryZoom;
          if (spiderfyOnMaxZoom || zoomToBoundsOnClick || spiderfyOnEveryZoom) {
            this.on("clusterclick clusterkeypress", this._zoomOrSpiderfy, this);
          }
          if (showCoverageOnHover) {
            this.on("clustermouseover", this._showCoverage, this);
            this.on("clustermouseout", this._hideCoverage, this);
            map.on("zoomend", this._hideCoverage, this);
          }
        },
        _zoomOrSpiderfy: function(e) {
          var cluster = e.layer, bottomCluster = cluster;
          if (e.type === "clusterkeypress" && e.originalEvent && e.originalEvent.keyCode !== 13) {
            return;
          }
          while (bottomCluster._childClusters.length === 1) {
            bottomCluster = bottomCluster._childClusters[0];
          }
          if (bottomCluster._zoom === this._maxZoom && bottomCluster._childCount === cluster._childCount && this.options.spiderfyOnMaxZoom) {
            cluster.spiderfy();
          } else if (this.options.zoomToBoundsOnClick) {
            cluster.zoomToBounds();
          }
          if (this.options.spiderfyOnEveryZoom) {
            cluster.spiderfy();
          }
          if (e.originalEvent && e.originalEvent.keyCode === 13) {
            this._map._container.focus();
          }
        },
        _showCoverage: function(e) {
          var map = this._map;
          if (this._inZoomAnimation) {
            return;
          }
          if (this._shownPolygon) {
            map.removeLayer(this._shownPolygon);
          }
          if (e.layer.getChildCount() > 2 && e.layer !== this._spiderfied) {
            this._shownPolygon = new L.Polygon(e.layer.getConvexHull(), this.options.polygonOptions);
            map.addLayer(this._shownPolygon);
          }
        },
        _hideCoverage: function() {
          if (this._shownPolygon) {
            this._map.removeLayer(this._shownPolygon);
            this._shownPolygon = null;
          }
        },
        _unbindEvents: function() {
          var spiderfyOnMaxZoom = this.options.spiderfyOnMaxZoom, showCoverageOnHover = this.options.showCoverageOnHover, zoomToBoundsOnClick = this.options.zoomToBoundsOnClick, spiderfyOnEveryZoom = this.options.spiderfyOnEveryZoom, map = this._map;
          if (spiderfyOnMaxZoom || zoomToBoundsOnClick || spiderfyOnEveryZoom) {
            this.off("clusterclick clusterkeypress", this._zoomOrSpiderfy, this);
          }
          if (showCoverageOnHover) {
            this.off("clustermouseover", this._showCoverage, this);
            this.off("clustermouseout", this._hideCoverage, this);
            map.off("zoomend", this._hideCoverage, this);
          }
        },
        _zoomEnd: function() {
          if (!this._map) {
            return;
          }
          this._mergeSplitClusters();
          this._zoom = Math.round(this._map._zoom);
          this._currentShownBounds = this._getExpandedVisibleBounds();
        },
        _moveEnd: function() {
          if (this._inZoomAnimation) {
            return;
          }
          var newBounds = this._getExpandedVisibleBounds();
          this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), this._zoom, newBounds);
          this._topClusterLevel._recursivelyAddChildrenToMap(null, Math.round(this._map._zoom), newBounds);
          this._currentShownBounds = newBounds;
          return;
        },
        _generateInitialClusters: function() {
          var maxZoom = Math.ceil(this._map.getMaxZoom()), minZoom = Math.floor(this._map.getMinZoom()), radius = this.options.maxClusterRadius, radiusFn = radius;
          if (typeof radius !== "function") {
            radiusFn = function() {
              return radius;
            };
          }
          if (this.options.disableClusteringAtZoom !== null) {
            maxZoom = this.options.disableClusteringAtZoom - 1;
          }
          this._maxZoom = maxZoom;
          this._gridClusters = {};
          this._gridUnclustered = {};
          for (var zoom = maxZoom; zoom >= minZoom; zoom--) {
            this._gridClusters[zoom] = new L.DistanceGrid(radiusFn(zoom));
            this._gridUnclustered[zoom] = new L.DistanceGrid(radiusFn(zoom));
          }
          this._topClusterLevel = new this._markerCluster(this, minZoom - 1);
        },
        //Zoom: Zoom to start adding at (Pass this._maxZoom to start at the bottom)
        _addLayer: function(layer, zoom) {
          var gridClusters = this._gridClusters, gridUnclustered = this._gridUnclustered, minZoom = Math.floor(this._map.getMinZoom()), markerPoint, z;
          if (this.options.singleMarkerMode) {
            this._overrideMarkerIcon(layer);
          }
          layer.on(this._childMarkerEventHandlers, this);
          for (; zoom >= minZoom; zoom--) {
            markerPoint = this._map.project(layer.getLatLng(), zoom);
            var closest = gridClusters[zoom].getNearObject(markerPoint);
            if (closest) {
              closest._addChild(layer);
              layer.__parent = closest;
              return;
            }
            closest = gridUnclustered[zoom].getNearObject(markerPoint);
            if (closest) {
              var parent = closest.__parent;
              if (parent) {
                this._removeLayer(closest, false);
              }
              var newCluster = new this._markerCluster(this, zoom, closest, layer);
              gridClusters[zoom].addObject(newCluster, this._map.project(newCluster._cLatLng, zoom));
              closest.__parent = newCluster;
              layer.__parent = newCluster;
              var lastParent = newCluster;
              for (z = zoom - 1; z > parent._zoom; z--) {
                lastParent = new this._markerCluster(this, z, lastParent);
                gridClusters[z].addObject(lastParent, this._map.project(closest.getLatLng(), z));
              }
              parent._addChild(lastParent);
              this._removeFromGridUnclustered(closest, zoom);
              return;
            }
            gridUnclustered[zoom].addObject(layer, markerPoint);
          }
          this._topClusterLevel._addChild(layer);
          layer.__parent = this._topClusterLevel;
          return;
        },
        /**
         * Refreshes the icon of all "dirty" visible clusters.
         * Non-visible "dirty" clusters will be updated when they are added to the map.
         * @private
         */
        _refreshClustersIcons: function() {
          this._featureGroup.eachLayer(function(c) {
            if (c instanceof L.MarkerCluster && c._iconNeedsUpdate) {
              c._updateIcon();
            }
          });
        },
        //Enqueue code to fire after the marker expand/contract has happened
        _enqueue: function(fn) {
          this._queue.push(fn);
          if (!this._queueTimeout) {
            this._queueTimeout = setTimeout(L.bind(this._processQueue, this), 300);
          }
        },
        _processQueue: function() {
          for (var i = 0; i < this._queue.length; i++) {
            this._queue[i].call(this);
          }
          this._queue.length = 0;
          clearTimeout(this._queueTimeout);
          this._queueTimeout = null;
        },
        //Merge and split any existing clusters that are too big or small
        _mergeSplitClusters: function() {
          var mapZoom = Math.round(this._map._zoom);
          this._processQueue();
          if (this._zoom < mapZoom && this._currentShownBounds.intersects(this._getExpandedVisibleBounds())) {
            this._animationStart();
            this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), this._zoom, this._getExpandedVisibleBounds());
            this._animationZoomIn(this._zoom, mapZoom);
          } else if (this._zoom > mapZoom) {
            this._animationStart();
            this._animationZoomOut(this._zoom, mapZoom);
          } else {
            this._moveEnd();
          }
        },
        //Gets the maps visible bounds expanded in each direction by the size of the screen (so the user cannot see an area we do not cover in one pan)
        _getExpandedVisibleBounds: function() {
          if (!this.options.removeOutsideVisibleBounds) {
            return this._mapBoundsInfinite;
          } else if (L.Browser.mobile) {
            return this._checkBoundsMaxLat(this._map.getBounds());
          }
          return this._checkBoundsMaxLat(this._map.getBounds().pad(1));
        },
        /**
         * Expands the latitude to Infinity (or -Infinity) if the input bounds reach the map projection maximum defined latitude
         * (in the case of Web/Spherical Mercator, it is 85.0511287798 / see https://en.wikipedia.org/wiki/Web_Mercator#Formulas).
         * Otherwise, the removeOutsideVisibleBounds option will remove markers beyond that limit, whereas the same markers without
         * this option (or outside MCG) will have their position floored (ceiled) by the projection and rendered at that limit,
         * making the user think that MCG "eats" them and never displays them again.
         * @param bounds L.LatLngBounds
         * @returns {L.LatLngBounds}
         * @private
         */
        _checkBoundsMaxLat: function(bounds) {
          var maxLat = this._maxLat;
          if (maxLat !== void 0) {
            if (bounds.getNorth() >= maxLat) {
              bounds._northEast.lat = Infinity;
            }
            if (bounds.getSouth() <= -maxLat) {
              bounds._southWest.lat = -Infinity;
            }
          }
          return bounds;
        },
        //Shared animation code
        _animationAddLayerNonAnimated: function(layer, newCluster) {
          if (newCluster === layer) {
            this._featureGroup.addLayer(layer);
          } else if (newCluster._childCount === 2) {
            newCluster._addToMap();
            var markers = newCluster.getAllChildMarkers();
            this._featureGroup.removeLayer(markers[0]);
            this._featureGroup.removeLayer(markers[1]);
          } else {
            newCluster._updateIcon();
          }
        },
        /**
         * Extracts individual (i.e. non-group) layers from a Layer Group.
         * @param group to extract layers from.
         * @param output {Array} in which to store the extracted layers.
         * @returns {*|Array}
         * @private
         */
        _extractNonGroupLayers: function(group, output) {
          var layers = group.getLayers(), i = 0, layer;
          output = output || [];
          for (; i < layers.length; i++) {
            layer = layers[i];
            if (layer instanceof L.LayerGroup) {
              this._extractNonGroupLayers(layer, output);
              continue;
            }
            output.push(layer);
          }
          return output;
        },
        /**
         * Implements the singleMarkerMode option.
         * @param layer Marker to re-style using the Clusters iconCreateFunction.
         * @returns {L.Icon} The newly created icon.
         * @private
         */
        _overrideMarkerIcon: function(layer) {
          var icon = layer.options.icon = this.options.iconCreateFunction({
            getChildCount: function() {
              return 1;
            },
            getAllChildMarkers: function() {
              return [layer];
            }
          });
          return icon;
        }
      });
      L.MarkerClusterGroup.include({
        _mapBoundsInfinite: new L.LatLngBounds(new L.LatLng(-Infinity, -Infinity), new L.LatLng(Infinity, Infinity))
      });
      L.MarkerClusterGroup.include({
        _noAnimation: {
          //Non Animated versions of everything
          _animationStart: function() {
          },
          _animationZoomIn: function(previousZoomLevel, newZoomLevel) {
            this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), previousZoomLevel);
            this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
            this.fire("animationend");
          },
          _animationZoomOut: function(previousZoomLevel, newZoomLevel) {
            this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), previousZoomLevel);
            this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
            this.fire("animationend");
          },
          _animationAddLayer: function(layer, newCluster) {
            this._animationAddLayerNonAnimated(layer, newCluster);
          }
        },
        _withAnimation: {
          //Animated versions here
          _animationStart: function() {
            this._map._mapPane.className += " leaflet-cluster-anim";
            this._inZoomAnimation++;
          },
          _animationZoomIn: function(previousZoomLevel, newZoomLevel) {
            var bounds = this._getExpandedVisibleBounds(), fg = this._featureGroup, minZoom = Math.floor(this._map.getMinZoom()), i;
            this._ignoreMove = true;
            this._topClusterLevel._recursively(bounds, previousZoomLevel, minZoom, function(c) {
              var startPos = c._latlng, markers = c._markers, m;
              if (!bounds.contains(startPos)) {
                startPos = null;
              }
              if (c._isSingleParent() && previousZoomLevel + 1 === newZoomLevel) {
                fg.removeLayer(c);
                c._recursivelyAddChildrenToMap(null, newZoomLevel, bounds);
              } else {
                c.clusterHide();
                c._recursivelyAddChildrenToMap(startPos, newZoomLevel, bounds);
              }
              for (i = markers.length - 1; i >= 0; i--) {
                m = markers[i];
                if (!bounds.contains(m._latlng)) {
                  fg.removeLayer(m);
                }
              }
            });
            this._forceLayout();
            this._topClusterLevel._recursivelyBecomeVisible(bounds, newZoomLevel);
            fg.eachLayer(function(n) {
              if (!(n instanceof L.MarkerCluster) && n._icon) {
                n.clusterShow();
              }
            });
            this._topClusterLevel._recursively(bounds, previousZoomLevel, newZoomLevel, function(c) {
              c._recursivelyRestoreChildPositions(newZoomLevel);
            });
            this._ignoreMove = false;
            this._enqueue(function() {
              this._topClusterLevel._recursively(bounds, previousZoomLevel, minZoom, function(c) {
                fg.removeLayer(c);
                c.clusterShow();
              });
              this._animationEnd();
            });
          },
          _animationZoomOut: function(previousZoomLevel, newZoomLevel) {
            this._animationZoomOutSingle(this._topClusterLevel, previousZoomLevel - 1, newZoomLevel);
            this._topClusterLevel._recursivelyAddChildrenToMap(null, newZoomLevel, this._getExpandedVisibleBounds());
            this._topClusterLevel._recursivelyRemoveChildrenFromMap(this._currentShownBounds, Math.floor(this._map.getMinZoom()), previousZoomLevel, this._getExpandedVisibleBounds());
          },
          _animationAddLayer: function(layer, newCluster) {
            var me = this, fg = this._featureGroup;
            fg.addLayer(layer);
            if (newCluster !== layer) {
              if (newCluster._childCount > 2) {
                newCluster._updateIcon();
                this._forceLayout();
                this._animationStart();
                layer._setPos(this._map.latLngToLayerPoint(newCluster.getLatLng()));
                layer.clusterHide();
                this._enqueue(function() {
                  fg.removeLayer(layer);
                  layer.clusterShow();
                  me._animationEnd();
                });
              } else {
                this._forceLayout();
                me._animationStart();
                me._animationZoomOutSingle(newCluster, this._map.getMaxZoom(), this._zoom);
              }
            }
          }
        },
        // Private methods for animated versions.
        _animationZoomOutSingle: function(cluster, previousZoomLevel, newZoomLevel) {
          var bounds = this._getExpandedVisibleBounds(), minZoom = Math.floor(this._map.getMinZoom());
          cluster._recursivelyAnimateChildrenInAndAddSelfToMap(bounds, minZoom, previousZoomLevel + 1, newZoomLevel);
          var me = this;
          this._forceLayout();
          cluster._recursivelyBecomeVisible(bounds, newZoomLevel);
          this._enqueue(function() {
            if (cluster._childCount === 1) {
              var m = cluster._markers[0];
              this._ignoreMove = true;
              m.setLatLng(m.getLatLng());
              this._ignoreMove = false;
              if (m.clusterShow) {
                m.clusterShow();
              }
            } else {
              cluster._recursively(bounds, newZoomLevel, minZoom, function(c) {
                c._recursivelyRemoveChildrenFromMap(bounds, minZoom, previousZoomLevel + 1);
              });
            }
            me._animationEnd();
          });
        },
        _animationEnd: function() {
          if (this._map) {
            this._map._mapPane.className = this._map._mapPane.className.replace(" leaflet-cluster-anim", "");
          }
          this._inZoomAnimation--;
          this.fire("animationend");
        },
        //Force a browser layout of stuff in the map
        // Should apply the current opacity and location to all elements so we can update them again for an animation
        _forceLayout: function() {
          L.Util.falseFn(document.body.offsetWidth);
        }
      });
      L.markerClusterGroup = function(options) {
        return new L.MarkerClusterGroup(options);
      };
      var MarkerCluster = L.MarkerCluster = L.Marker.extend({
        options: L.Icon.prototype.options,
        initialize: function(group, zoom, a, b) {
          L.Marker.prototype.initialize.call(
            this,
            a ? a._cLatLng || a.getLatLng() : new L.LatLng(0, 0),
            { icon: this, pane: group.options.clusterPane }
          );
          this._group = group;
          this._zoom = zoom;
          this._markers = [];
          this._childClusters = [];
          this._childCount = 0;
          this._iconNeedsUpdate = true;
          this._boundsNeedUpdate = true;
          this._bounds = new L.LatLngBounds();
          if (a) {
            this._addChild(a);
          }
          if (b) {
            this._addChild(b);
          }
        },
        //Recursively retrieve all child markers of this cluster
        getAllChildMarkers: function(storageArray, ignoreDraggedMarker) {
          storageArray = storageArray || [];
          for (var i = this._childClusters.length - 1; i >= 0; i--) {
            this._childClusters[i].getAllChildMarkers(storageArray, ignoreDraggedMarker);
          }
          for (var j = this._markers.length - 1; j >= 0; j--) {
            if (ignoreDraggedMarker && this._markers[j].__dragStart) {
              continue;
            }
            storageArray.push(this._markers[j]);
          }
          return storageArray;
        },
        //Returns the count of how many child markers we have
        getChildCount: function() {
          return this._childCount;
        },
        //Zoom to the minimum of showing all of the child markers, or the extents of this cluster
        zoomToBounds: function(fitBoundsOptions) {
          var childClusters = this._childClusters.slice(), map = this._group._map, boundsZoom = map.getBoundsZoom(this._bounds), zoom = this._zoom + 1, mapZoom = map.getZoom(), i;
          while (childClusters.length > 0 && boundsZoom > zoom) {
            zoom++;
            var newClusters = [];
            for (i = 0; i < childClusters.length; i++) {
              newClusters = newClusters.concat(childClusters[i]._childClusters);
            }
            childClusters = newClusters;
          }
          if (boundsZoom > zoom) {
            this._group._map.setView(this._latlng, zoom);
          } else if (boundsZoom <= mapZoom) {
            this._group._map.setView(this._latlng, mapZoom + 1);
          } else {
            this._group._map.fitBounds(this._bounds, fitBoundsOptions);
          }
        },
        getBounds: function() {
          var bounds = new L.LatLngBounds();
          bounds.extend(this._bounds);
          return bounds;
        },
        _updateIcon: function() {
          this._iconNeedsUpdate = true;
          if (this._icon) {
            this.setIcon(this);
          }
        },
        //Cludge for Icon, we pretend to be an icon for performance
        createIcon: function() {
          if (this._iconNeedsUpdate) {
            this._iconObj = this._group.options.iconCreateFunction(this);
            this._iconNeedsUpdate = false;
          }
          return this._iconObj.createIcon();
        },
        createShadow: function() {
          return this._iconObj.createShadow();
        },
        _addChild: function(new1, isNotificationFromChild) {
          this._iconNeedsUpdate = true;
          this._boundsNeedUpdate = true;
          this._setClusterCenter(new1);
          if (new1 instanceof L.MarkerCluster) {
            if (!isNotificationFromChild) {
              this._childClusters.push(new1);
              new1.__parent = this;
            }
            this._childCount += new1._childCount;
          } else {
            if (!isNotificationFromChild) {
              this._markers.push(new1);
            }
            this._childCount++;
          }
          if (this.__parent) {
            this.__parent._addChild(new1, true);
          }
        },
        /**
         * Makes sure the cluster center is set. If not, uses the child center if it is a cluster, or the marker position.
         * @param child L.MarkerCluster|L.Marker that will be used as cluster center if not defined yet.
         * @private
         */
        _setClusterCenter: function(child) {
          if (!this._cLatLng) {
            this._cLatLng = child._cLatLng || child._latlng;
          }
        },
        /**
         * Assigns impossible bounding values so that the next extend entirely determines the new bounds.
         * This method avoids having to trash the previous L.LatLngBounds object and to create a new one, which is much slower for this class.
         * As long as the bounds are not extended, most other methods would probably fail, as they would with bounds initialized but not extended.
         * @private
         */
        _resetBounds: function() {
          var bounds = this._bounds;
          if (bounds._southWest) {
            bounds._southWest.lat = Infinity;
            bounds._southWest.lng = Infinity;
          }
          if (bounds._northEast) {
            bounds._northEast.lat = -Infinity;
            bounds._northEast.lng = -Infinity;
          }
        },
        _recalculateBounds: function() {
          var markers = this._markers, childClusters = this._childClusters, latSum = 0, lngSum = 0, totalCount = this._childCount, i, child, childLatLng, childCount;
          if (totalCount === 0) {
            return;
          }
          this._resetBounds();
          for (i = 0; i < markers.length; i++) {
            childLatLng = markers[i]._latlng;
            this._bounds.extend(childLatLng);
            latSum += childLatLng.lat;
            lngSum += childLatLng.lng;
          }
          for (i = 0; i < childClusters.length; i++) {
            child = childClusters[i];
            if (child._boundsNeedUpdate) {
              child._recalculateBounds();
            }
            this._bounds.extend(child._bounds);
            childLatLng = child._wLatLng;
            childCount = child._childCount;
            latSum += childLatLng.lat * childCount;
            lngSum += childLatLng.lng * childCount;
          }
          this._latlng = this._wLatLng = new L.LatLng(latSum / totalCount, lngSum / totalCount);
          this._boundsNeedUpdate = false;
        },
        //Set our markers position as given and add it to the map
        _addToMap: function(startPos) {
          if (startPos) {
            this._backupLatlng = this._latlng;
            this.setLatLng(startPos);
          }
          this._group._featureGroup.addLayer(this);
        },
        _recursivelyAnimateChildrenIn: function(bounds, center, maxZoom) {
          this._recursively(
            bounds,
            this._group._map.getMinZoom(),
            maxZoom - 1,
            function(c) {
              var markers = c._markers, i, m;
              for (i = markers.length - 1; i >= 0; i--) {
                m = markers[i];
                if (m._icon) {
                  m._setPos(center);
                  m.clusterHide();
                }
              }
            },
            function(c) {
              var childClusters = c._childClusters, j, cm;
              for (j = childClusters.length - 1; j >= 0; j--) {
                cm = childClusters[j];
                if (cm._icon) {
                  cm._setPos(center);
                  cm.clusterHide();
                }
              }
            }
          );
        },
        _recursivelyAnimateChildrenInAndAddSelfToMap: function(bounds, mapMinZoom, previousZoomLevel, newZoomLevel) {
          this._recursively(
            bounds,
            newZoomLevel,
            mapMinZoom,
            function(c) {
              c._recursivelyAnimateChildrenIn(bounds, c._group._map.latLngToLayerPoint(c.getLatLng()).round(), previousZoomLevel);
              if (c._isSingleParent() && previousZoomLevel - 1 === newZoomLevel) {
                c.clusterShow();
                c._recursivelyRemoveChildrenFromMap(bounds, mapMinZoom, previousZoomLevel);
              } else {
                c.clusterHide();
              }
              c._addToMap();
            }
          );
        },
        _recursivelyBecomeVisible: function(bounds, zoomLevel) {
          this._recursively(bounds, this._group._map.getMinZoom(), zoomLevel, null, function(c) {
            c.clusterShow();
          });
        },
        _recursivelyAddChildrenToMap: function(startPos, zoomLevel, bounds) {
          this._recursively(
            bounds,
            this._group._map.getMinZoom() - 1,
            zoomLevel,
            function(c) {
              if (zoomLevel === c._zoom) {
                return;
              }
              for (var i = c._markers.length - 1; i >= 0; i--) {
                var nm = c._markers[i];
                if (!bounds.contains(nm._latlng)) {
                  continue;
                }
                if (startPos) {
                  nm._backupLatlng = nm.getLatLng();
                  nm.setLatLng(startPos);
                  if (nm.clusterHide) {
                    nm.clusterHide();
                  }
                }
                c._group._featureGroup.addLayer(nm);
              }
            },
            function(c) {
              c._addToMap(startPos);
            }
          );
        },
        _recursivelyRestoreChildPositions: function(zoomLevel) {
          for (var i = this._markers.length - 1; i >= 0; i--) {
            var nm = this._markers[i];
            if (nm._backupLatlng) {
              nm.setLatLng(nm._backupLatlng);
              delete nm._backupLatlng;
            }
          }
          if (zoomLevel - 1 === this._zoom) {
            for (var j = this._childClusters.length - 1; j >= 0; j--) {
              this._childClusters[j]._restorePosition();
            }
          } else {
            for (var k = this._childClusters.length - 1; k >= 0; k--) {
              this._childClusters[k]._recursivelyRestoreChildPositions(zoomLevel);
            }
          }
        },
        _restorePosition: function() {
          if (this._backupLatlng) {
            this.setLatLng(this._backupLatlng);
            delete this._backupLatlng;
          }
        },
        //exceptBounds: If set, don't remove any markers/clusters in it
        _recursivelyRemoveChildrenFromMap: function(previousBounds, mapMinZoom, zoomLevel, exceptBounds) {
          var m, i;
          this._recursively(
            previousBounds,
            mapMinZoom - 1,
            zoomLevel - 1,
            function(c) {
              for (i = c._markers.length - 1; i >= 0; i--) {
                m = c._markers[i];
                if (!exceptBounds || !exceptBounds.contains(m._latlng)) {
                  c._group._featureGroup.removeLayer(m);
                  if (m.clusterShow) {
                    m.clusterShow();
                  }
                }
              }
            },
            function(c) {
              for (i = c._childClusters.length - 1; i >= 0; i--) {
                m = c._childClusters[i];
                if (!exceptBounds || !exceptBounds.contains(m._latlng)) {
                  c._group._featureGroup.removeLayer(m);
                  if (m.clusterShow) {
                    m.clusterShow();
                  }
                }
              }
            }
          );
        },
        //Run the given functions recursively to this and child clusters
        // boundsToApplyTo: a L.LatLngBounds representing the bounds of what clusters to recurse in to
        // zoomLevelToStart: zoom level to start running functions (inclusive)
        // zoomLevelToStop: zoom level to stop running functions (inclusive)
        // runAtEveryLevel: function that takes an L.MarkerCluster as an argument that should be applied on every level
        // runAtBottomLevel: function that takes an L.MarkerCluster as an argument that should be applied at only the bottom level
        _recursively: function(boundsToApplyTo, zoomLevelToStart, zoomLevelToStop, runAtEveryLevel, runAtBottomLevel) {
          var childClusters = this._childClusters, zoom = this._zoom, i, c;
          if (zoomLevelToStart <= zoom) {
            if (runAtEveryLevel) {
              runAtEveryLevel(this);
            }
            if (runAtBottomLevel && zoom === zoomLevelToStop) {
              runAtBottomLevel(this);
            }
          }
          if (zoom < zoomLevelToStart || zoom < zoomLevelToStop) {
            for (i = childClusters.length - 1; i >= 0; i--) {
              c = childClusters[i];
              if (c._boundsNeedUpdate) {
                c._recalculateBounds();
              }
              if (boundsToApplyTo.intersects(c._bounds)) {
                c._recursively(boundsToApplyTo, zoomLevelToStart, zoomLevelToStop, runAtEveryLevel, runAtBottomLevel);
              }
            }
          }
        },
        //Returns true if we are the parent of only one cluster and that cluster is the same as us
        _isSingleParent: function() {
          return this._childClusters.length > 0 && this._childClusters[0]._childCount === this._childCount;
        }
      });
      L.Marker.include({
        clusterHide: function() {
          var backup = this.options.opacity;
          this.setOpacity(0);
          this.options.opacity = backup;
          return this;
        },
        clusterShow: function() {
          return this.setOpacity(this.options.opacity);
        }
      });
      L.DistanceGrid = function(cellSize) {
        this._cellSize = cellSize;
        this._sqCellSize = cellSize * cellSize;
        this._grid = {};
        this._objectPoint = {};
      };
      L.DistanceGrid.prototype = {
        addObject: function(obj, point) {
          var x = this._getCoord(point.x), y = this._getCoord(point.y), grid = this._grid, row = grid[y] = grid[y] || {}, cell = row[x] = row[x] || [], stamp = L.Util.stamp(obj);
          this._objectPoint[stamp] = point;
          cell.push(obj);
        },
        updateObject: function(obj, point) {
          this.removeObject(obj);
          this.addObject(obj, point);
        },
        //Returns true if the object was found
        removeObject: function(obj, point) {
          var x = this._getCoord(point.x), y = this._getCoord(point.y), grid = this._grid, row = grid[y] = grid[y] || {}, cell = row[x] = row[x] || [], i, len;
          delete this._objectPoint[L.Util.stamp(obj)];
          for (i = 0, len = cell.length; i < len; i++) {
            if (cell[i] === obj) {
              cell.splice(i, 1);
              if (len === 1) {
                delete row[x];
              }
              return true;
            }
          }
        },
        eachObject: function(fn, context) {
          var i, j, k, len, row, cell, removed, grid = this._grid;
          for (i in grid) {
            row = grid[i];
            for (j in row) {
              cell = row[j];
              for (k = 0, len = cell.length; k < len; k++) {
                removed = fn.call(context, cell[k]);
                if (removed) {
                  k--;
                  len--;
                }
              }
            }
          }
        },
        getNearObject: function(point) {
          var x = this._getCoord(point.x), y = this._getCoord(point.y), i, j, k, row, cell, len, obj, dist, objectPoint = this._objectPoint, closestDistSq = this._sqCellSize, closest = null;
          for (i = y - 1; i <= y + 1; i++) {
            row = this._grid[i];
            if (row) {
              for (j = x - 1; j <= x + 1; j++) {
                cell = row[j];
                if (cell) {
                  for (k = 0, len = cell.length; k < len; k++) {
                    obj = cell[k];
                    dist = this._sqDist(objectPoint[L.Util.stamp(obj)], point);
                    if (dist < closestDistSq || dist <= closestDistSq && closest === null) {
                      closestDistSq = dist;
                      closest = obj;
                    }
                  }
                }
              }
            }
          }
          return closest;
        },
        _getCoord: function(x) {
          var coord = Math.floor(x / this._cellSize);
          return isFinite(coord) ? coord : x;
        },
        _sqDist: function(p, p2) {
          var dx = p2.x - p.x, dy = p2.y - p.y;
          return dx * dx + dy * dy;
        }
      };
      (function() {
        L.QuickHull = {
          /*
           * @param {Object} cpt a point to be measured from the baseline
           * @param {Array} bl the baseline, as represented by a two-element
           *   array of latlng objects.
           * @returns {Number} an approximate distance measure
           */
          getDistant: function(cpt, bl) {
            var vY = bl[1].lat - bl[0].lat, vX = bl[0].lng - bl[1].lng;
            return vX * (cpt.lat - bl[0].lat) + vY * (cpt.lng - bl[0].lng);
          },
          /*
           * @param {Array} baseLine a two-element array of latlng objects
           *   representing the baseline to project from
           * @param {Array} latLngs an array of latlng objects
           * @returns {Object} the maximum point and all new points to stay
           *   in consideration for the hull.
           */
          findMostDistantPointFromBaseLine: function(baseLine, latLngs) {
            var maxD = 0, maxPt = null, newPoints = [], i, pt, d;
            for (i = latLngs.length - 1; i >= 0; i--) {
              pt = latLngs[i];
              d = this.getDistant(pt, baseLine);
              if (d > 0) {
                newPoints.push(pt);
              } else {
                continue;
              }
              if (d > maxD) {
                maxD = d;
                maxPt = pt;
              }
            }
            return { maxPoint: maxPt, newPoints };
          },
          /*
           * Given a baseline, compute the convex hull of latLngs as an array
           * of latLngs.
           *
           * @param {Array} latLngs
           * @returns {Array}
           */
          buildConvexHull: function(baseLine, latLngs) {
            var convexHullBaseLines = [], t = this.findMostDistantPointFromBaseLine(baseLine, latLngs);
            if (t.maxPoint) {
              convexHullBaseLines = convexHullBaseLines.concat(
                this.buildConvexHull([baseLine[0], t.maxPoint], t.newPoints)
              );
              convexHullBaseLines = convexHullBaseLines.concat(
                this.buildConvexHull([t.maxPoint, baseLine[1]], t.newPoints)
              );
              return convexHullBaseLines;
            } else {
              return [baseLine[0]];
            }
          },
          /*
           * Given an array of latlngs, compute a convex hull as an array
           * of latlngs
           *
           * @param {Array} latLngs
           * @returns {Array}
           */
          getConvexHull: function(latLngs) {
            var maxLat = false, minLat = false, maxLng = false, minLng = false, maxLatPt = null, minLatPt = null, maxLngPt = null, minLngPt = null, maxPt = null, minPt = null, i;
            for (i = latLngs.length - 1; i >= 0; i--) {
              var pt = latLngs[i];
              if (maxLat === false || pt.lat > maxLat) {
                maxLatPt = pt;
                maxLat = pt.lat;
              }
              if (minLat === false || pt.lat < minLat) {
                minLatPt = pt;
                minLat = pt.lat;
              }
              if (maxLng === false || pt.lng > maxLng) {
                maxLngPt = pt;
                maxLng = pt.lng;
              }
              if (minLng === false || pt.lng < minLng) {
                minLngPt = pt;
                minLng = pt.lng;
              }
            }
            if (minLat !== maxLat) {
              minPt = minLatPt;
              maxPt = maxLatPt;
            } else {
              minPt = minLngPt;
              maxPt = maxLngPt;
            }
            var ch = [].concat(
              this.buildConvexHull([minPt, maxPt], latLngs),
              this.buildConvexHull([maxPt, minPt], latLngs)
            );
            return ch;
          }
        };
      })();
      L.MarkerCluster.include({
        getConvexHull: function() {
          var childMarkers = this.getAllChildMarkers(), points = [], p, i;
          for (i = childMarkers.length - 1; i >= 0; i--) {
            p = childMarkers[i].getLatLng();
            points.push(p);
          }
          return L.QuickHull.getConvexHull(points);
        }
      });
      L.MarkerCluster.include({
        _2PI: Math.PI * 2,
        _circleFootSeparation: 25,
        //related to circumference of circle
        _circleStartAngle: 0,
        _spiralFootSeparation: 28,
        //related to size of spiral (experiment!)
        _spiralLengthStart: 11,
        _spiralLengthFactor: 5,
        _circleSpiralSwitchover: 9,
        //show spiral instead of circle from this marker count upwards.
        // 0 -> always spiral; Infinity -> always circle
        spiderfy: function() {
          if (this._group._spiderfied === this || this._group._inZoomAnimation) {
            return;
          }
          var childMarkers = this.getAllChildMarkers(null, true), group = this._group, map = group._map, center = map.latLngToLayerPoint(this._latlng), positions;
          this._group._unspiderfy();
          this._group._spiderfied = this;
          if (this._group.options.spiderfyShapePositions) {
            positions = this._group.options.spiderfyShapePositions(childMarkers.length, center);
          } else if (childMarkers.length >= this._circleSpiralSwitchover) {
            positions = this._generatePointsSpiral(childMarkers.length, center);
          } else {
            center.y += 10;
            positions = this._generatePointsCircle(childMarkers.length, center);
          }
          this._animationSpiderfy(childMarkers, positions);
        },
        unspiderfy: function(zoomDetails) {
          if (this._group._inZoomAnimation) {
            return;
          }
          this._animationUnspiderfy(zoomDetails);
          this._group._spiderfied = null;
        },
        _generatePointsCircle: function(count, centerPt) {
          var circumference = this._group.options.spiderfyDistanceMultiplier * this._circleFootSeparation * (2 + count), legLength = circumference / this._2PI, angleStep = this._2PI / count, res = [], i, angle;
          legLength = Math.max(legLength, 35);
          res.length = count;
          for (i = 0; i < count; i++) {
            angle = this._circleStartAngle + i * angleStep;
            res[i] = new L.Point(centerPt.x + legLength * Math.cos(angle), centerPt.y + legLength * Math.sin(angle))._round();
          }
          return res;
        },
        _generatePointsSpiral: function(count, centerPt) {
          var spiderfyDistanceMultiplier = this._group.options.spiderfyDistanceMultiplier, legLength = spiderfyDistanceMultiplier * this._spiralLengthStart, separation = spiderfyDistanceMultiplier * this._spiralFootSeparation, lengthFactor = spiderfyDistanceMultiplier * this._spiralLengthFactor * this._2PI, angle = 0, res = [], i;
          res.length = count;
          for (i = count; i >= 0; i--) {
            if (i < count) {
              res[i] = new L.Point(centerPt.x + legLength * Math.cos(angle), centerPt.y + legLength * Math.sin(angle))._round();
            }
            angle += separation / legLength + i * 5e-4;
            legLength += lengthFactor / angle;
          }
          return res;
        },
        _noanimationUnspiderfy: function() {
          var group = this._group, map = group._map, fg = group._featureGroup, childMarkers = this.getAllChildMarkers(null, true), m, i;
          group._ignoreMove = true;
          this.setOpacity(1);
          for (i = childMarkers.length - 1; i >= 0; i--) {
            m = childMarkers[i];
            fg.removeLayer(m);
            if (m._preSpiderfyLatlng) {
              m.setLatLng(m._preSpiderfyLatlng);
              delete m._preSpiderfyLatlng;
            }
            if (m.setZIndexOffset) {
              m.setZIndexOffset(0);
            }
            if (m._spiderLeg) {
              map.removeLayer(m._spiderLeg);
              delete m._spiderLeg;
            }
          }
          group.fire("unspiderfied", {
            cluster: this,
            markers: childMarkers
          });
          group._ignoreMove = false;
          group._spiderfied = null;
        }
      });
      L.MarkerClusterNonAnimated = L.MarkerCluster.extend({
        _animationSpiderfy: function(childMarkers, positions) {
          var group = this._group, map = group._map, fg = group._featureGroup, legOptions = this._group.options.spiderLegPolylineOptions, i, m, leg, newPos;
          group._ignoreMove = true;
          for (i = 0; i < childMarkers.length; i++) {
            newPos = map.layerPointToLatLng(positions[i]);
            m = childMarkers[i];
            leg = new L.Polyline([this._latlng, newPos], legOptions);
            map.addLayer(leg);
            m._spiderLeg = leg;
            m._preSpiderfyLatlng = m._latlng;
            m.setLatLng(newPos);
            if (m.setZIndexOffset) {
              m.setZIndexOffset(1e6);
            }
            fg.addLayer(m);
          }
          this.setOpacity(0.3);
          group._ignoreMove = false;
          group.fire("spiderfied", {
            cluster: this,
            markers: childMarkers
          });
        },
        _animationUnspiderfy: function() {
          this._noanimationUnspiderfy();
        }
      });
      L.MarkerCluster.include({
        _animationSpiderfy: function(childMarkers, positions) {
          var me = this, group = this._group, map = group._map, fg = group._featureGroup, thisLayerLatLng = this._latlng, thisLayerPos = map.latLngToLayerPoint(thisLayerLatLng), svg = L.Path.SVG, legOptions = L.extend({}, this._group.options.spiderLegPolylineOptions), finalLegOpacity = legOptions.opacity, i, m, leg, legPath, legLength, newPos;
          if (finalLegOpacity === void 0) {
            finalLegOpacity = L.MarkerClusterGroup.prototype.options.spiderLegPolylineOptions.opacity;
          }
          if (svg) {
            legOptions.opacity = 0;
            legOptions.className = (legOptions.className || "") + " leaflet-cluster-spider-leg";
          } else {
            legOptions.opacity = finalLegOpacity;
          }
          group._ignoreMove = true;
          for (i = 0; i < childMarkers.length; i++) {
            m = childMarkers[i];
            newPos = map.layerPointToLatLng(positions[i]);
            leg = new L.Polyline([thisLayerLatLng, newPos], legOptions);
            map.addLayer(leg);
            m._spiderLeg = leg;
            if (svg) {
              legPath = leg._path;
              legLength = legPath.getTotalLength() + 0.1;
              legPath.style.strokeDasharray = legLength;
              legPath.style.strokeDashoffset = legLength;
            }
            if (m.setZIndexOffset) {
              m.setZIndexOffset(1e6);
            }
            if (m.clusterHide) {
              m.clusterHide();
            }
            fg.addLayer(m);
            if (m._setPos) {
              m._setPos(thisLayerPos);
            }
          }
          group._forceLayout();
          group._animationStart();
          for (i = childMarkers.length - 1; i >= 0; i--) {
            newPos = map.layerPointToLatLng(positions[i]);
            m = childMarkers[i];
            m._preSpiderfyLatlng = m._latlng;
            m.setLatLng(newPos);
            if (m.clusterShow) {
              m.clusterShow();
            }
            if (svg) {
              leg = m._spiderLeg;
              legPath = leg._path;
              legPath.style.strokeDashoffset = 0;
              leg.setStyle({ opacity: finalLegOpacity });
            }
          }
          this.setOpacity(0.3);
          group._ignoreMove = false;
          setTimeout(function() {
            group._animationEnd();
            group.fire("spiderfied", {
              cluster: me,
              markers: childMarkers
            });
          }, 200);
        },
        _animationUnspiderfy: function(zoomDetails) {
          var me = this, group = this._group, map = group._map, fg = group._featureGroup, thisLayerPos = zoomDetails ? map._latLngToNewLayerPoint(this._latlng, zoomDetails.zoom, zoomDetails.center) : map.latLngToLayerPoint(this._latlng), childMarkers = this.getAllChildMarkers(null, true), svg = L.Path.SVG, m, i, leg, legPath, legLength, nonAnimatable;
          group._ignoreMove = true;
          group._animationStart();
          this.setOpacity(1);
          for (i = childMarkers.length - 1; i >= 0; i--) {
            m = childMarkers[i];
            if (!m._preSpiderfyLatlng) {
              continue;
            }
            m.closePopup();
            m.setLatLng(m._preSpiderfyLatlng);
            delete m._preSpiderfyLatlng;
            nonAnimatable = true;
            if (m._setPos) {
              m._setPos(thisLayerPos);
              nonAnimatable = false;
            }
            if (m.clusterHide) {
              m.clusterHide();
              nonAnimatable = false;
            }
            if (nonAnimatable) {
              fg.removeLayer(m);
            }
            if (svg) {
              leg = m._spiderLeg;
              legPath = leg._path;
              legLength = legPath.getTotalLength() + 0.1;
              legPath.style.strokeDashoffset = legLength;
              leg.setStyle({ opacity: 0 });
            }
          }
          group._ignoreMove = false;
          setTimeout(function() {
            var stillThereChildCount = 0;
            for (i = childMarkers.length - 1; i >= 0; i--) {
              m = childMarkers[i];
              if (m._spiderLeg) {
                stillThereChildCount++;
              }
            }
            for (i = childMarkers.length - 1; i >= 0; i--) {
              m = childMarkers[i];
              if (!m._spiderLeg) {
                continue;
              }
              if (m.clusterShow) {
                m.clusterShow();
              }
              if (m.setZIndexOffset) {
                m.setZIndexOffset(0);
              }
              if (stillThereChildCount > 1) {
                fg.removeLayer(m);
              }
              map.removeLayer(m._spiderLeg);
              delete m._spiderLeg;
            }
            group._animationEnd();
            group.fire("unspiderfied", {
              cluster: me,
              markers: childMarkers
            });
          }, 200);
        }
      });
      L.MarkerClusterGroup.include({
        //The MarkerCluster currently spiderfied (if any)
        _spiderfied: null,
        unspiderfy: function() {
          this._unspiderfy.apply(this, arguments);
        },
        _spiderfierOnAdd: function() {
          this._map.on("click", this._unspiderfyWrapper, this);
          if (this._map.options.zoomAnimation) {
            this._map.on("zoomstart", this._unspiderfyZoomStart, this);
          }
          this._map.on("zoomend", this._noanimationUnspiderfy, this);
          if (!L.Browser.touch) {
            this._map.getRenderer(this);
          }
        },
        _spiderfierOnRemove: function() {
          this._map.off("click", this._unspiderfyWrapper, this);
          this._map.off("zoomstart", this._unspiderfyZoomStart, this);
          this._map.off("zoomanim", this._unspiderfyZoomAnim, this);
          this._map.off("zoomend", this._noanimationUnspiderfy, this);
          this._noanimationUnspiderfy();
        },
        //On zoom start we add a zoomanim handler so that we are guaranteed to be last (after markers are animated)
        //This means we can define the animation they do rather than Markers doing an animation to their actual location
        _unspiderfyZoomStart: function() {
          if (!this._map) {
            return;
          }
          this._map.on("zoomanim", this._unspiderfyZoomAnim, this);
        },
        _unspiderfyZoomAnim: function(zoomDetails) {
          if (L.DomUtil.hasClass(this._map._mapPane, "leaflet-touching")) {
            return;
          }
          this._map.off("zoomanim", this._unspiderfyZoomAnim, this);
          this._unspiderfy(zoomDetails);
        },
        _unspiderfyWrapper: function() {
          this._unspiderfy();
        },
        _unspiderfy: function(zoomDetails) {
          if (this._spiderfied) {
            this._spiderfied.unspiderfy(zoomDetails);
          }
        },
        _noanimationUnspiderfy: function() {
          if (this._spiderfied) {
            this._spiderfied._noanimationUnspiderfy();
          }
        },
        //If the given layer is currently being spiderfied then we unspiderfy it so it isn't on the map anymore etc
        _unspiderfyLayer: function(layer) {
          if (layer._spiderLeg) {
            this._featureGroup.removeLayer(layer);
            if (layer.clusterShow) {
              layer.clusterShow();
            }
            if (layer.setZIndexOffset) {
              layer.setZIndexOffset(0);
            }
            this._map.removeLayer(layer._spiderLeg);
            delete layer._spiderLeg;
          }
        }
      });
      L.MarkerClusterGroup.include({
        /**
         * Updates the icon of all clusters which are parents of the given marker(s).
         * In singleMarkerMode, also updates the given marker(s) icon.
         * @param layers L.MarkerClusterGroup|L.LayerGroup|Array(L.Marker)|Map(L.Marker)|
         * L.MarkerCluster|L.Marker (optional) list of markers (or single marker) whose parent
         * clusters need to be updated. If not provided, retrieves all child markers of this.
         * @returns {L.MarkerClusterGroup}
         */
        refreshClusters: function(layers) {
          if (!layers) {
            layers = this._topClusterLevel.getAllChildMarkers();
          } else if (layers instanceof L.MarkerClusterGroup) {
            layers = layers._topClusterLevel.getAllChildMarkers();
          } else if (layers instanceof L.LayerGroup) {
            layers = layers._layers;
          } else if (layers instanceof L.MarkerCluster) {
            layers = layers.getAllChildMarkers();
          } else if (layers instanceof L.Marker) {
            layers = [layers];
          }
          this._flagParentsIconsNeedUpdate(layers);
          this._refreshClustersIcons();
          if (this.options.singleMarkerMode) {
            this._refreshSingleMarkerModeMarkers(layers);
          }
          return this;
        },
        /**
         * Simply flags all parent clusters of the given markers as having a "dirty" icon.
         * @param layers Array(L.Marker)|Map(L.Marker) list of markers.
         * @private
         */
        _flagParentsIconsNeedUpdate: function(layers) {
          var id, parent;
          for (id in layers) {
            parent = layers[id].__parent;
            while (parent) {
              parent._iconNeedsUpdate = true;
              parent = parent.__parent;
            }
          }
        },
        /**
         * Re-draws the icon of the supplied markers.
         * To be used in singleMarkerMode only.
         * @param layers Array(L.Marker)|Map(L.Marker) list of markers.
         * @private
         */
        _refreshSingleMarkerModeMarkers: function(layers) {
          var id, layer;
          for (id in layers) {
            layer = layers[id];
            if (this.hasLayer(layer)) {
              layer.setIcon(this._overrideMarkerIcon(layer));
            }
          }
        }
      });
      L.Marker.include({
        /**
         * Updates the given options in the marker's icon and refreshes the marker.
         * @param options map object of icon options.
         * @param directlyRefreshClusters boolean (optional) true to trigger
         * MCG.refreshClustersOf() right away with this single marker.
         * @returns {L.Marker}
         */
        refreshIconOptions: function(options, directlyRefreshClusters) {
          var icon = this.options.icon;
          L.setOptions(icon, options);
          this.setIcon(icon);
          if (directlyRefreshClusters && this.__parent) {
            this.__parent._group.refreshClusters(this);
          }
          return this;
        }
      });
      exports$12.MarkerClusterGroup = MarkerClusterGroup2;
      exports$12.MarkerCluster = MarkerCluster;
      Object.defineProperty(exports$12, "__esModule", { value: true });
    });
  })(leaflet_markerclusterSrc$1, leaflet_markerclusterSrc$1.exports);
  return leaflet_markerclusterSrc$1.exports;
}
requireLeaflet_markerclusterSrc();
function getPropsAndEvents(props) {
  let clusterProps = {};
  let clusterEvents = {};
  const { children, ...rest } = props;
  Object.entries(rest).forEach(([propName, prop]) => {
    if (propName.startsWith("on")) {
      clusterEvents = { ...clusterEvents, [propName]: prop };
    } else {
      clusterProps = { ...clusterProps, [propName]: prop };
    }
  });
  return { clusterProps, clusterEvents };
}
function createMarkerClusterGroup(props, context) {
  const { clusterProps, clusterEvents } = getPropsAndEvents(props);
  const markerClusterGroup = new L$1.MarkerClusterGroup(clusterProps);
  Object.entries(clusterEvents).forEach(([eventAsProp, callback]) => {
    const clusterEvent = `cluster${eventAsProp.substring(2).toLowerCase()}`;
    markerClusterGroup.on(clusterEvent, callback);
  });
  return createElementObject(
    markerClusterGroup,
    extendContext(context, { layerContainer: markerClusterGroup })
  );
}
var updateMarkerCluster = (instance, props, prevProps) => {
  const { clusterProps, clusterEvents } = getPropsAndEvents(props);
  const { clusterProps: prevClusterProps, clusterEvents: prevClusterEvents } = getPropsAndEvents(prevProps);
  Object.keys(clusterProps).forEach((key) => {
    if (clusterProps[key] !== prevClusterProps[key]) {
      instance.options[key] = clusterProps[key];
    }
  });
  Object.entries(prevClusterEvents).forEach(([eventAsProp, callback]) => {
    const clusterEvent = `cluster${eventAsProp.substring(2).toLowerCase()}`;
    instance.off(clusterEvent, callback);
  });
  Object.entries(clusterEvents).forEach(([eventAsProp, callback]) => {
    const clusterEvent = `cluster${eventAsProp.substring(2).toLowerCase()}`;
    instance.on(clusterEvent, callback);
  });
};
var MarkerClusterGroup = createPathComponent(
  createMarkerClusterGroup,
  updateMarkerCluster
);
var index_default = MarkerClusterGroup;
!(function() {
  function t(i) {
    return this instanceof t ? (this._canvas = i = "string" == typeof i ? document.getElementById(i) : i, this._ctx = i.getContext("2d"), this._width = i.width, this._height = i.height, this._max = 1, void this.clear()) : new t(i);
  }
  t.prototype = { defaultRadius: 25, defaultGradient: { 0.4: "blue", 0.6: "cyan", 0.7: "lime", 0.8: "yellow", 1: "red" }, data: function(t2, i) {
    return this._data = t2, this;
  }, max: function(t2) {
    return this._max = t2, this;
  }, add: function(t2) {
    return this._data.push(t2), this;
  }, clear: function() {
    return this._data = [], this;
  }, radius: function(t2, i) {
    i = i || 15;
    var a = this._circle = document.createElement("canvas"), s = a.getContext("2d"), e = this._r = t2 + i;
    return a.width = a.height = 2 * e, s.shadowOffsetX = s.shadowOffsetY = 200, s.shadowBlur = i, s.shadowColor = "black", s.beginPath(), s.arc(e - 200, e - 200, t2, 0, 2 * Math.PI, true), s.closePath(), s.fill(), this;
  }, gradient: function(t2) {
    var i = document.createElement("canvas"), a = i.getContext("2d"), s = a.createLinearGradient(0, 0, 0, 256);
    i.width = 1, i.height = 256;
    for (var e in t2) s.addColorStop(e, t2[e]);
    return a.fillStyle = s, a.fillRect(0, 0, 1, 256), this._grad = a.getImageData(0, 0, 1, 256).data, this;
  }, draw: function(t2) {
    this._circle || this.radius(this.defaultRadius), this._grad || this.gradient(this.defaultGradient);
    var i = this._ctx;
    i.clearRect(0, 0, this._width, this._height);
    for (var a, s = 0, e = this._data.length; e > s; s++) a = this._data[s], i.globalAlpha = Math.max(a[2] / this._max, t2 || 0.05), i.drawImage(this._circle, a[0] - this._r, a[1] - this._r);
    var n = i.getImageData(0, 0, this._width, this._height);
    return this._colorize(n.data, this._grad), i.putImageData(n, 0, 0), this;
  }, _colorize: function(t2, i) {
    for (var a, s = 3, e = t2.length; e > s; s += 4) a = 4 * t2[s], a && (t2[s - 3] = i[a], t2[s - 2] = i[a + 1], t2[s - 1] = i[a + 2]);
  } }, window.simpleheat = t;
})(), /*
 (c) 2014, Vladimir Agafonkin
 Leaflet.heat, a tiny and fast heatmap plugin for Leaflet.
 https://github.com/Leaflet/Leaflet.heat
*/
L.HeatLayer = (L.Layer ? L.Layer : L.Class).extend({ initialize: function(t, i) {
  this._latlngs = t, L.setOptions(this, i);
}, setLatLngs: function(t) {
  return this._latlngs = t, this.redraw();
}, addLatLng: function(t) {
  return this._latlngs.push(t), this.redraw();
}, setOptions: function(t) {
  return L.setOptions(this, t), this._heat && this._updateOptions(), this.redraw();
}, redraw: function() {
  return !this._heat || this._frame || this._map._animating || (this._frame = L.Util.requestAnimFrame(this._redraw, this)), this;
}, onAdd: function(t) {
  this._map = t, this._canvas || this._initCanvas(), t._panes.overlayPane.appendChild(this._canvas), t.on("moveend", this._reset, this), t.options.zoomAnimation && L.Browser.any3d && t.on("zoomanim", this._animateZoom, this), this._reset();
}, onRemove: function(t) {
  t.getPanes().overlayPane.removeChild(this._canvas), t.off("moveend", this._reset, this), t.options.zoomAnimation && t.off("zoomanim", this._animateZoom, this);
}, addTo: function(t) {
  return t.addLayer(this), this;
}, _initCanvas: function() {
  var t = this._canvas = L.DomUtil.create("canvas", "leaflet-heatmap-layer leaflet-layer"), i = L.DomUtil.testProp(["transformOrigin", "WebkitTransformOrigin", "msTransformOrigin"]);
  t.style[i] = "50% 50%";
  var a = this._map.getSize();
  t.width = a.x, t.height = a.y;
  var s = this._map.options.zoomAnimation && L.Browser.any3d;
  L.DomUtil.addClass(t, "leaflet-zoom-" + (s ? "animated" : "hide")), this._heat = simpleheat(t), this._updateOptions();
}, _updateOptions: function() {
  this._heat.radius(this.options.radius || this._heat.defaultRadius, this.options.blur), this.options.gradient && this._heat.gradient(this.options.gradient), this.options.max && this._heat.max(this.options.max);
}, _reset: function() {
  var t = this._map.containerPointToLayerPoint([0, 0]);
  L.DomUtil.setPosition(this._canvas, t);
  var i = this._map.getSize();
  this._heat._width !== i.x && (this._canvas.width = this._heat._width = i.x), this._heat._height !== i.y && (this._canvas.height = this._heat._height = i.y), this._redraw();
}, _redraw: function() {
  var t, i, a, s, e, n, h, o, r, d = [], _ = this._heat._r, l = this._map.getSize(), m = new L.Bounds(L.point([-_, -_]), l.add([_, _])), c = void 0 === this.options.max ? 1 : this.options.max, u = void 0 === this.options.maxZoom ? this._map.getMaxZoom() : this.options.maxZoom, f = 1 / Math.pow(2, Math.max(0, Math.min(u - this._map.getZoom(), 12))), g = _ / 2, p = [], v = this._map._getMapPanePos(), w = v.x % g, y = v.y % g;
  for (t = 0, i = this._latlngs.length; i > t; t++) if (a = this._map.latLngToContainerPoint(this._latlngs[t]), m.contains(a)) {
    e = Math.floor((a.x - w) / g) + 2, n = Math.floor((a.y - y) / g) + 2;
    var x = void 0 !== this._latlngs[t].alt ? this._latlngs[t].alt : void 0 !== this._latlngs[t][2] ? +this._latlngs[t][2] : 1;
    r = x * f, p[n] = p[n] || [], s = p[n][e], s ? (s[0] = (s[0] * s[2] + a.x * r) / (s[2] + r), s[1] = (s[1] * s[2] + a.y * r) / (s[2] + r), s[2] += r) : p[n][e] = [a.x, a.y, r];
  }
  for (t = 0, i = p.length; i > t; t++) if (p[t]) for (h = 0, o = p[t].length; o > h; h++) s = p[t][h], s && d.push([Math.round(s[0]), Math.round(s[1]), Math.min(s[2], c)]);
  this._heat.data(d).draw(this.options.minOpacity), this._frame = null;
}, _animateZoom: function(t) {
  var i = this._map.getZoomScale(t.zoom), a = this._map._getCenterOffset(t.center)._multiplyBy(-i).subtract(this._map._getMapPanePos());
  L.DomUtil.setTransform ? L.DomUtil.setTransform(this._canvas, a, i) : this._canvas.style[L.DomUtil.TRANSFORM] = L.DomUtil.getTranslateString(a) + " scale(" + i + ")";
} }), L.heatLayer = function(t, i) {
  return new L.HeatLayer(t, i);
};
function HeatmapLayer({ points }) {
  const map = useMap();
  reactExports.useEffect(() => {
    if (!points || points.length === 0) return;
    const maxJackpot = Math.max(...points.map((p) => p.jackpotCount), 1);
    const heatArray = points.map((p) => [
      p.lat,
      p.lng,
      // 正規化 intensity，加上底氣 (至少 0.2) 讓沒有頭獎的區域也能稍微顯示熱度
      p.jackpotCount / maxJackpot * 0.8 + 0.2
    ]);
    const heatLayer = L$1.heatLayer(heatArray, {
      radius: 25,
      blur: 15,
      maxZoom: 13,
      max: 1,
      gradient: {
        0.4: "blue",
        0.6: "lime",
        0.8: "yellow",
        1: "red"
      }
    });
    heatLayer.addTo(map);
    return () => {
      map.removeLayer(heatLayer);
    };
  }, [map, points]);
  return null;
}
function RatingDisplay({ retailerId, compact = false }) {
  const [summary, setSummary] = reactExports.useState(null);
  const [reviews, setReviews] = reactExports.useState([]);
  const [showReviews, setShowReviews] = reactExports.useState(false);
  reactExports.useEffect(() => {
    fetchRatingSummary(retailerId).then(setSummary).catch(() => {
    });
  }, [retailerId]);
  function loadReviews() {
    if (reviews.length > 0) {
      setShowReviews(!showReviews);
      return;
    }
    fetchRetailerRatings(retailerId).then((data) => {
      setReviews(data);
      setShowReviews(true);
    }).catch(() => {
    });
  }
  if (!summary || summary.totalCount === 0) {
    if (compact) return null;
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display rating-display--empty", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-display__no-data", children: "尚無評分" }) });
  }
  function renderStars(value) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display__stars", children: [1, 2, 3, 4, 5].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      Star,
      {
        size: compact ? 14 : 16,
        fill: n <= Math.round(value) ? "#d4af37" : "none",
        color: n <= Math.round(value) ? "#d4af37" : "var(--border-subtle)"
      },
      n
    )) });
  }
  if (compact) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-display rating-display--compact", children: [
      renderStars(summary.avgRating),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-display__avg", children: summary.avgRating }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__count", children: [
        "(",
        summary.totalCount,
        ")"
      ] })
    ] });
  }
  const topServiceTags = Object.entries(summary.serviceTagStats).sort(([, a], [, b]) => b - a).slice(0, 4);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-display", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-display__header", children: [
      renderStars(summary.avgRating),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-display__avg", children: summary.avgRating }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__count", children: [
        "(",
        summary.totalCount,
        " 則評分)"
      ] })
    ] }),
    topServiceTags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display__tags", children: topServiceTags.map(([tag, count]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__tag-stat", children: [
      tag,
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__tag-pct", children: [
        Math.round(count / summary.totalCount * 100),
        "%"
      ] })
    ] }, tag)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "rating-display__toggle-reviews", onClick: loadReviews, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { size: 14 }),
      showReviews ? "收合評論" : `查看評論 (${summary.totalCount})`
    ] }),
    showReviews && reviews.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display__reviews", children: reviews.slice(0, 5).map((r) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-display__review", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-display__review-header", children: [
        r.userPictureUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { className: "rating-display__review-avatar", src: r.userPictureUrl, alt: "" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__review-name", children: [
          r.userName,
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-display__review-level", children: [
            "Lv.",
            r.userLevel
          ] })
        ] }),
        r.isGpsVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { size: 14, className: "rating-display__verified" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display__review-stars", children: [1, 2, 3, 4, 5].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 12, fill: n <= r.rating ? "#d4af37" : "none", color: n <= r.rating ? "#d4af37" : "#555" }, n)) })
      ] }),
      r.comment && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rating-display__review-text", children: r.comment }),
      r.serviceTags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-display__review-tags", children: r.serviceTags.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-display__mini-tag", children: t }, t)) })
    ] }, r.id)) })
  ] });
}
const SERVICE_TAGS = [
  { key: "環境乾淨", icon: "✨" },
  { key: "店員親切", icon: "😊" },
  { key: "品項齊全", icon: "📦" },
  { key: "攻略豐富", icon: "📋" },
  { key: "交通方便", icon: "🚗" },
  { key: "願意再訪", icon: "🔄" }
];
const FACILITY_TAGS = [
  { key: "冷氣", icon: "❄️" },
  { key: "廁所", icon: "🚻" },
  { key: "座位", icon: "💺" },
  { key: "Wi-Fi", icon: "📶" },
  { key: "無障礙", icon: "♿" },
  { key: "電子支付", icon: "💳" },
  { key: "攻略", icon: "📋" },
  { key: "挑號", icon: "🔢" },
  { key: "刮板", icon: "🪣" },
  { key: "放大鏡", icon: "🔍" },
  { key: "老花眼鏡", icon: "👓" },
  { key: "報紙", icon: "📰" },
  { key: "運彩轉播", icon: "📺" }
];
function RatingPanel({ retailerId, retailerName, onClose, onSubmitted }) {
  const { isLoggedIn, loginWithLine } = useAuth();
  const [rating, setRating] = reactExports.useState(0);
  const [hoverRating, setHoverRating] = reactExports.useState(0);
  const [selectedServiceTags, setSelectedServiceTags] = reactExports.useState([]);
  const [selectedFacilityTags, setSelectedFacilityTags] = reactExports.useState([]);
  const [comment, setComment] = reactExports.useState("");
  const [submitting, setSubmitting] = reactExports.useState(false);
  const [error, setError] = reactExports.useState("");
  const [success, setSuccess] = reactExports.useState(false);
  function toggleTag(tag, type) {
    if (type === "service") {
      setSelectedServiceTags(
        (prev) => prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
      );
    } else {
      setSelectedFacilityTags(
        (prev) => prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
      );
    }
  }
  async function handleSubmit() {
    if (rating === 0) {
      setError("請選擇星等");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      let lat;
      let lng;
      if (navigator.geolocation) {
        try {
          const pos = await new Promise(
            (resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5e3 })
          );
          lat = pos.coords.latitude;
          lng = pos.coords.longitude;
        } catch {
        }
      }
      await submitRating({
        retailerId,
        rating,
        serviceTags: selectedServiceTags,
        facilityTags: selectedFacilityTags,
        comment,
        lat,
        lng
      });
      setSuccess(true);
      onSubmitted?.();
      setTimeout(onClose, 1500);
    } catch (err) {
      if (err && typeof err === "object" && "response" in err) {
        const axiosErr = err;
        setError(axiosErr.response?.data?.detail || "評分失敗");
      } else {
        setError("評分失敗，請稍後再試");
      }
    } finally {
      setSubmitting(false);
    }
  }
  if (!isLoggedIn) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-panel__overlay", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "rating-panel__close", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 20 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__login-prompt", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "🔒 請先登入" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "登入 LINE 以維持評分公正性" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "rating-panel__line-btn", onClick: loginWithLine, children: "LINE 登入" })
      ] })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-panel__overlay", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel", onClick: (e) => e.stopPropagation(), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "rating-panel__close", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 20 }) }),
    success ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__success", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-panel__success-icon", children: "🎉" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "感謝您的評分！" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "+20 Karma 積分" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "rating-panel__title", children: [
        "評分「",
        retailerName,
        "」"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__stars", children: [
        [1, 2, 3, 4, 5].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: `rating-panel__star ${n <= (hoverRating || rating) ? "rating-panel__star--active" : ""}`,
            onMouseEnter: () => setHoverRating(n),
            onMouseLeave: () => setHoverRating(0),
            onClick: () => setRating(n),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 32, fill: n <= (hoverRating || rating) ? "#d4af37" : "none" })
          },
          n
        )),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-panel__rating-text", children: rating > 0 ? `${rating} 星` : "點擊評分" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "📌 服務品質" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-panel__tags", children: SERVICE_TAGS.map(({ key, icon }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            className: `rating-panel__tag ${selectedServiceTags.includes(key) ? "rating-panel__tag--active" : ""}`,
            onClick: () => toggleTag(key, "service"),
            children: [
              icon,
              " ",
              key
            ]
          },
          key
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { children: [
          "🏪 硬體設施 ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "rating-panel__crowd-badge", children: "群眾回報" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rating-panel__tags", children: FACILITY_TAGS.map(({ key, icon }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            className: `rating-panel__tag ${selectedFacilityTags.includes(key) ? "rating-panel__tag--active" : ""}`,
            onClick: () => toggleTag(key, "facility"),
            children: [
              icon,
              " ",
              key
            ]
          },
          key
        )) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rating-panel__section", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { children: "💬 留下一句話（選填）" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            className: "rating-panel__comment",
            placeholder: "分享您的經驗...",
            value: comment,
            onChange: (e) => setComment(e.target.value),
            maxLength: 200,
            rows: 3
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "rating-panel__char-count", children: [
          comment.length,
          "/200"
        ] })
      ] }),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rating-panel__error", children: error }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "rating-panel__submit",
          onClick: handleSubmit,
          disabled: submitting || rating === 0,
          children: submitting ? "送出中..." : "送出評分"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "rating-panel__hint", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 12 }),
        " 系統會自動偵測您的位置做為驗證"
      ] })
    ] })
  ] }) });
}
delete L$1.Icon.Default.prototype._getIconUrl;
L$1.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png"
});
const CITIES = [
  "台北市",
  "新北市",
  "桃園市",
  "台中市",
  "台南市",
  "高雄市",
  "基隆市",
  "新竹市",
  "新竹縣",
  "苗栗縣",
  "彰化縣",
  "南投縣",
  "雲林縣",
  "嘉義市",
  "嘉義縣",
  "屏東縣",
  "宜蘭縣",
  "花蓮縣",
  "台東縣",
  "澎湖縣",
  "金門縣",
  "連江縣"
];
const SOURCES = ["全部", "台灣彩券", "台灣運彩"];
const TAG_FILTERS = [
  { key: "hasAC", label: "❄️ 冷氣" },
  { key: "hasSeats", label: "💺 座位" },
  { key: "hasWifi", label: "📶 Wi-Fi" },
  { key: "hasEPay", label: "💳 電子支付" },
  { key: "hasStrategy", label: "📋 攻略" },
  { key: "hasNumberPick", label: "🔢 挑號" },
  { key: "hasScratchBoard", label: "🪣 刮板" },
  { key: "hasSportTV", label: "📺 運彩轉播" },
  { key: "hasReadingGlasses", label: "👓 老花眼鏡" }
];
const FACILITY_ICONS = {
  hasAC: "❄️",
  hasToilet: "🚻",
  hasSeats: "💺",
  hasWifi: "📶",
  hasAccessibility: "♿",
  hasEPay: "💳",
  hasStrategy: "📋",
  hasNumberPick: "🔢",
  hasScratchBoard: "🪣",
  hasMagnifier: "🔍",
  hasReadingGlasses: "👓",
  hasNewspaper: "📰",
  hasSportTV: "📺"
};
const FACILITY_LABELS = {
  hasAC: "冷氣",
  hasToilet: "廁所",
  hasSeats: "座位",
  hasWifi: "Wi-Fi",
  hasAccessibility: "無障礙",
  hasEPay: "電子支付",
  hasStrategy: "攻略",
  hasNumberPick: "挑號",
  hasScratchBoard: "刮板",
  hasMagnifier: "放大鏡",
  hasReadingGlasses: "老花眼鏡",
  hasNewspaper: "報紙",
  hasSportTV: "運彩轉播"
};
function getActiveFacilities(r) {
  return Object.keys(FACILITY_ICONS).filter((k) => r[k]);
}
const INVENTORY_STATUS = [
  { value: "充足", label: "🟢 充足", color: "#22c55e" },
  { value: "少量", label: "🟡 少量", color: "#eab308" },
  { value: "完售", label: "🔴 完售", color: "#ef4444" }
];
const LEVEL_COLORS = [
  "#94a3b8",
  "#6ee7b7",
  "#34d399",
  "#10b981",
  "#f59e0b",
  "#f97316",
  "#ef4444",
  "#dc2626",
  "#a855f7",
  "#d4af37"
];
const PAGE_SIZE = 50;
function normalizeCity(city) {
  return city ? city.replace(/臺/g, "台") : "";
}
function groupRetailersByAddress(retailers) {
  const addressMap = /* @__PURE__ */ new Map();
  for (const r of retailers) {
    if (r.lat == null || r.lng == null) continue;
    const key = r.address.trim();
    if (!key) continue;
    if (!addressMap.has(key)) {
      addressMap.set(key, { lottery: null, sport: null });
    }
    const group = addressMap.get(key);
    if (r.source === "台灣彩券") {
      if (!group.lottery) group.lottery = r;
    } else {
      if (!group.sport) group.sport = r;
    }
  }
  const result = [];
  for (const [address, group] of addressMap) {
    const representative = group.lottery || group.sport;
    const type = group.lottery && group.sport ? "combined" : group.lottery ? "lotteryOnly" : "sportOnly";
    const isPro = group.lottery?.merchantTier === "pro" || group.sport?.merchantTier === "pro";
    const isJackpot = (group.lottery?.jackpotCount || 0) > 0 || (group.sport?.jackpotCount || 0) > 0;
    result.push({
      key: `${representative.id}-${address}`,
      lat: representative.lat,
      lng: representative.lng,
      address,
      lottery: group.lottery,
      sport: group.sport,
      type,
      isPro,
      isJackpot
    });
  }
  return result;
}
const LOTTERY_COLOR = "#F5A623";
const SPORT_COLOR = "#E74C3C";
function createMarkerIcon(type, isPro = false, isJackpot = false) {
  const proClass = isPro ? " marker--pro" : "";
  const jackpotClass = isJackpot ? " marker--jackpot" : "";
  const proCrown = isPro ? '<span class="marker-pro-crown">👑</span>' : "";
  const jackpotBadge = isJackpot ? '<span class="marker-jackpot-badge">🏆</span>' : "";
  if (type === "combined") {
    return L$1.divIcon({
      className: `compound-marker-wrapper${proClass}${jackpotClass}`,
      html: `
                <div class="compound-marker">
                    ${proCrown}
                    ${jackpotBadge}
                    <div class="compound-marker__lottery">🎫</div>
                    <div class="compound-marker__sport">⚽</div>
                    <div class="compound-marker__tail"></div>
                </div>
            `,
      iconSize: [32, 44],
      iconAnchor: [16, 44],
      popupAnchor: [0, -44]
    });
  }
  const color = type === "lotteryOnly" ? LOTTERY_COLOR : SPORT_COLOR;
  const emoji = type === "lotteryOnly" ? "🎫" : "⚽";
  return L$1.divIcon({
    className: `single-marker-wrapper${proClass}${jackpotClass}`,
    html: `
            <div class="single-marker" style="background: ${color};">
                ${proCrown}
                ${jackpotBadge}
                <span>${emoji}</span>
                <div class="single-marker__tail" style="border-top-color: ${color};"></div>
            </div>
        `,
    iconSize: [30, 40],
    iconAnchor: [15, 40],
    popupAnchor: [0, -40]
  });
}
function RetailerPopupSection({
  retailer,
  themeColor,
  getGoogleMapsUrl,
  openInventoryReport,
  setRatingRetailer,
  officialInventory
}) {
  const isPro = retailer.merchantTier === "pro";
  const facilities = isPro ? getActiveFacilities(retailer) : [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `compound-popup__section ${isPro ? "compound-popup__section--pro" : ""}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "compound-popup__header", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: "compound-popup__name", children: [
        retailer.name,
        retailer.jackpotCount && retailer.jackpotCount > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "popup-jackpot-badge", title: `已開出 ${retailer.jackpotCount} 次頭獎`, children: [
          "🏆 ",
          retailer.jackpotCount,
          " 次頭獎"
        ] }) : null,
        isPro && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "popup-pro-badge", children: "👑 PRO" }),
        retailer.isClaimed && !isPro && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "popup-verified-badge", children: "✅" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "span",
        {
          className: "compound-popup__source-tag",
          style: { background: `${themeColor}20`, color: themeColor },
          children: [
            retailer.source === "台灣彩券" ? "🎫" : "⚽",
            " ",
            retailer.source
          ]
        }
      )
    ] }),
    isPro && retailer.announcement && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "popup-announcement", children: [
      "📢 ",
      retailer.announcement
    ] }),
    facilities.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "popup-facilities", children: facilities.map((f) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "popup-facility-tag", title: FACILITY_LABELS[f], children: FACILITY_ICONS[f] }, f)) }),
    officialInventory && officialInventory.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "popup-official-inventory", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "popup-official-inventory__header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { size: 14 }),
        " 商家官方庫存"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "popup-official-inventory__grid", children: officialInventory.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "official-inventory-item", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "official-item-name", children: item.itemName }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `official-item-status status--${item.status === "充足" ? "green" : item.status === "少量" ? "yellow" : "red"}`, children: item.status })
      ] }, item.itemName)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(RatingDisplay, { retailerId: retailer.id, compact: true }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "compound-popup__actions", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => openInventoryReport(retailer),
          className: "compound-popup__btn",
          children: "📦 庫存"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setRatingRetailer(retailer),
          className: "compound-popup__btn",
          children: "⭐ 評分"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: getGoogleMapsUrl(retailer),
          target: "_blank",
          rel: "noreferrer",
          className: "compound-popup__nav-btn",
          children: "🧭 導航"
        }
      ),
      !retailer.isClaimed && /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: `/merchant/claim/${retailer.id}`,
          className: "compound-popup__btn",
          style: { textDecoration: "none", background: "#e0f2fe", color: "#0369a1" },
          children: "🙋‍♂️ 認領"
        }
      )
    ] })
  ] });
}
function ClusteredMarkers({
  retailers,
  getGoogleMapsUrl,
  openInventoryReport,
  setRatingRetailer,
  officialInventoryCache,
  onMarkerClick
}) {
  const grouped = reactExports.useMemo(() => groupRetailersByAddress(retailers), [retailers]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    index_default,
    {
      chunkedLoading: true,
      maxClusterRadius: 60,
      spiderfyOnMaxZoom: true,
      showCoverageOnHover: false,
      iconCreateFunction: (cluster) => {
        const count = cluster.getChildCount();
        let sizeClass = "marker-cluster-small";
        if (count >= 100) sizeClass = "marker-cluster-large";
        else if (count >= 10) sizeClass = "marker-cluster-medium";
        return L$1.divIcon({
          html: `<div><span>${count}</span></div>`,
          className: `marker-cluster ${sizeClass} marker-cluster--gold`,
          iconSize: L$1.point(40, 40)
        });
      },
      children: grouped.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        Marker,
        {
          position: [g.lat, g.lng],
          icon: createMarkerIcon(g.type, g.isPro, g.isJackpot),
          zIndexOffset: g.isPro || g.isJackpot ? 1e3 : 0,
          eventHandlers: {
            click: () => {
              const rs = [];
              if (g.lottery) rs.push(g.lottery);
              if (g.sport) rs.push(g.sport);
              onMarkerClick(rs);
            }
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, { minWidth: 240, maxWidth: 320, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "compound-popup", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "compound-popup__address", children: [
              "📍 ",
              g.address
            ] }),
            g.lottery && /* @__PURE__ */ jsxRuntimeExports.jsx(
              RetailerPopupSection,
              {
                retailer: g.lottery,
                themeColor: LOTTERY_COLOR,
                getGoogleMapsUrl,
                openInventoryReport,
                setRatingRetailer,
                officialInventory: officialInventoryCache[g.lottery.id]
              }
            ),
            g.type === "combined" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "compound-popup__divider" }),
            g.sport && /* @__PURE__ */ jsxRuntimeExports.jsx(
              RetailerPopupSection,
              {
                retailer: g.sport,
                themeColor: SPORT_COLOR,
                getGoogleMapsUrl,
                openInventoryReport,
                setRatingRetailer,
                officialInventory: officialInventoryCache[g.sport.id]
              }
            )
          ] }) })
        },
        g.key
      ))
    }
  );
}
function CommunityMap() {
  const { user } = useUser();
  const [retailers, setRetailers] = reactExports.useState([]);
  const [loadingRetailers, setLoadingRetailers] = reactExports.useState(true);
  const [search, setSearch] = reactExports.useState("");
  const [filterCity, setFilterCity] = reactExports.useState("");
  const [filterDistrict, setFilterDistrict] = reactExports.useState("");
  const [filterSource, setFilterSource] = reactExports.useState("全部");
  const [showFilters, setShowFilters] = reactExports.useState(false);
  const [activeTags, setActiveTags] = reactExports.useState([]);
  const [showTagFilters, setShowTagFilters] = reactExports.useState(false);
  const [displayCount, setDisplayCount] = reactExports.useState(PAGE_SIZE);
  const [viewMode, setViewMode] = reactExports.useState("list");
  const [heatmapPoints, setHeatmapPoints] = reactExports.useState([]);
  const [showOnlyJackpot, setShowOnlyJackpot] = reactExports.useState(false);
  const handleRetailerClick = reactExports.useCallback((retailerId) => {
    recordRetailerClick(retailerId).catch(() => {
    });
  }, []);
  const handleMarkerClick = reactExports.useCallback((rs) => {
    rs.forEach((r) => handleRetailerClick(r.id));
  }, [handleRetailerClick]);
  const [checkins, setCheckins] = reactExports.useState([]);
  const [city, setCity] = reactExports.useState("");
  const [amount, setAmount] = reactExports.useState("");
  const [gameName, setGameName] = reactExports.useState("");
  const [submitting, setSubmitting] = reactExports.useState(false);
  const [showCheckin, setShowCheckin] = reactExports.useState(false);
  const [showInventoryReport, setShowInventoryReport] = reactExports.useState(false);
  const [inventoryRetailer, setInventoryRetailer] = reactExports.useState(null);
  const [inventoryItem, setInventoryItem] = reactExports.useState("");
  const [inventoryStatus, setInventoryStatus] = reactExports.useState("");
  const [reportingInventory, setReportingInventory] = reactExports.useState(false);
  const [reportSearchInput, setReportSearchInput] = reactExports.useState("");
  const [reportSearchResults, setReportSearchResults] = reactExports.useState([]);
  const [reportSearchLoading, setReportSearchLoading] = reactExports.useState(false);
  const [inventoryCache, setInventoryCache] = reactExports.useState({});
  const [officialInventoryCache, setOfficialInventoryCache] = reactExports.useState({});
  const [festival, setFestival] = reactExports.useState(null);
  const [ratingRetailer, setRatingRetailer] = reactExports.useState(null);
  reactExports.useEffect(() => {
    loadData();
  }, []);
  async function loadData() {
    try {
      setLoadingRetailers(true);
      const [retData, chkData, festData, heatData] = await Promise.all([
        fetchRetailers(),
        fetchCheckins(),
        fetchFestivalStatus().catch(() => null),
        fetchHeatmap().catch(() => [])
      ]);
      setRetailers(retData);
      setCheckins(chkData);
      if (festData) setFestival(festData);
      setHeatmapPoints(heatData);
      const claimedIds = retData.filter((r) => r.isClaimed).map((r) => r.id);
      if (claimedIds.length > 0) {
        claimedIds.slice(0, 20).forEach(async (id) => {
          try {
            const data = await fetchMerchantOfficialInventory(id);
            setOfficialInventoryCache((prev) => ({ ...prev, [id]: data.items }));
          } catch {
          }
        });
      }
    } catch {
      setRetailers([]);
      setCheckins([]);
    } finally {
      setLoadingRetailers(false);
    }
  }
  const availableDistricts = reactExports.useMemo(() => {
    if (!filterCity) return [];
    const normFilter = normalizeCity(filterCity);
    const districts = retailers.filter((r) => normalizeCity(r.city) === normFilter && r.district).map((r) => r.district);
    return Array.from(new Set(districts)).sort();
  }, [retailers, filterCity]);
  const filtered = reactExports.useMemo(() => {
    let result = [...retailers];
    if (search) {
      const kw = search.toLowerCase();
      result = result.filter(
        (r) => r.name.toLowerCase().includes(kw) || r.address.toLowerCase().includes(kw)
      );
    }
    if (filterCity) {
      const normFilter = normalizeCity(filterCity);
      result = result.filter((r) => normalizeCity(r.city) === normFilter);
    }
    if (filterDistrict) {
      result = result.filter((r) => r.district === filterDistrict);
    }
    if (filterSource !== "全部") {
      result = result.filter((r) => r.source === filterSource);
    }
    if (activeTags.length > 0) {
      result = result.filter(
        (r) => activeTags.every((tag) => r[tag])
      );
    }
    result.sort((a, b) => {
      const aPro = a.merchantTier === "pro" ? 1 : 0;
      const bPro = b.merchantTier === "pro" ? 1 : 0;
      return bPro - aPro;
    });
    if (showOnlyJackpot) {
      result = result.filter((r) => (r.jackpotCount || 0) > 0);
    }
    return result;
  }, [retailers, search, filterCity, filterDistrict, filterSource, activeTags, showOnlyJackpot]);
  const cityStats = reactExports.useMemo(() => {
    const stats = {};
    retailers.forEach((r) => {
      const normCity = normalizeCity(r.city);
      if (!stats[normCity]) stats[normCity] = { lottery: 0, sport: 0, total: 0 };
      stats[normCity].total++;
      if (r.source === "台灣彩券") stats[normCity].lottery++;
      else stats[normCity].sport++;
    });
    return stats;
  }, [retailers]);
  const checkinStats = checkins.reduce((acc, c) => {
    const normCity = normalizeCity(c.city);
    if (!acc[normCity]) acc[normCity] = { count: 0, total: 0 };
    acc[normCity].count++;
    acc[normCity].total += c.amount;
    return acc;
  }, {});
  function getGoogleMapsUrl(r) {
    const q = encodeURIComponent(`${r.name} ${r.address}`);
    return `https://www.google.com/maps/search/${q}`;
  }
  function toggleTag(tag) {
    setActiveTags(
      (prev) => prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }
  async function handleSubmit() {
    if (!city || !amount) return;
    setSubmitting(true);
    try {
      const newCheckin = await createCheckin({
        city,
        amount: Number(amount),
        gameName
      });
      setCheckins([newCheckin, ...checkins]);
      setCity("");
      setAmount("");
      setGameName("");
    } catch {
    } finally {
      setSubmitting(false);
    }
  }
  function openInventoryReport(r) {
    setInventoryRetailer(r);
    setInventoryItem("");
    setInventoryStatus("");
    setReportSearchInput("");
    setShowInventoryReport(true);
    setReportSearchLoading(true);
    searchScratchcardsPublic("").then(setReportSearchResults).finally(() => setReportSearchLoading(false));
  }
  async function handleInventoryReport() {
    if (!inventoryRetailer || !inventoryItem || !inventoryStatus || !user) return;
    setReportingInventory(true);
    try {
      let lat;
      let lng;
      if (navigator.geolocation) {
        try {
          const pos = await new Promise(
            (resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5e3 })
          );
          lat = pos.coords.latitude;
          lng = pos.coords.longitude;
        } catch {
        }
      }
      await reportInventory({
        retailerId: inventoryRetailer.id,
        userId: user.id,
        item: inventoryItem,
        status: inventoryStatus,
        lat,
        lng
      });
      loadInventoryForRetailer(inventoryRetailer.id);
      setShowInventoryReport(false);
    } catch {
    } finally {
      setReportingInventory(false);
    }
  }
  const loadInventoryForRetailer = reactExports.useCallback(async (retailerId) => {
    try {
      const data = await fetchInventory(retailerId);
      setInventoryCache((prev) => ({ ...prev, [retailerId]: data.items }));
    } catch {
    }
  }, []);
  function handleLoadMore() {
    setDisplayCount((prev) => prev + PAGE_SIZE);
  }
  reactExports.useEffect(() => {
    setDisplayCount(PAGE_SIZE);
  }, [search, filterCity, filterDistrict, filterSource, activeTags]);
  const displayedRetailers = filtered.slice(0, displayCount);
  const hasMore = displayCount < filtered.length;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      SeoHead,
      {
        title: "經銷商地圖 — 全台彩券行搜尋與庫存查詢",
        description: "搜尋全台彩券經銷商，查看設施標籤、庫存狀態、營業資訊與導航。支援地圖模式與列表模式切換。",
        path: "/map",
        jsonLd: {
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "台灣彩券經銷商",
          description: "全台台灣彩券與運動彩券經銷商地圖，提供庫存查詢、設施標籤與導航功能。",
          geo: { "@type": "GeoCoordinates", latitude: 23.6978, longitude: 120.9605 }
        }
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "community-map__hero", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        className: "community-map__hero-content",
        initial: { opacity: 0, y: 30 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.6 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "community-map__title", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 32 }),
            "財神到 — 社群地圖"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "community-map__subtitle", children: [
            "全台 ",
            retailers.length.toLocaleString(),
            " 間彩券行 · 搜尋附近的投注站"
          ] }),
          user && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__karma-badge", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 14, style: { color: LEVEL_COLORS[user.karmaLevel - 1] } }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { style: { color: LEVEL_COLORS[user.karmaLevel - 1] }, children: [
              "Lv.",
              user.karmaLevel
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__karma-title", children: user.levelTitle }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__karma-pts", children: [
              user.karmaPoints,
              " 積分"
            ] })
          ] })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: festival?.isActive && /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.section,
      {
        className: "community-map__festival-banner",
        initial: { opacity: 0, y: -20 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -20 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(PartyPopper, { size: 20 }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__festival-info", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: festival.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: festival.description })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { size: 18, className: "community-map__festival-flame" })
        ]
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__content container", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.section,
        {
          className: "community-map__search-section",
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: 0.1 },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__search-bar", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { size: 18 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "搜尋投注站名稱或地址...",
                  value: search,
                  onChange: (e) => setSearch(e.target.value)
                }
              ),
              search && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "community-map__clear-btn", onClick: () => setSearch(""), children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 16 }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__filter-row", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__source-tabs", children: SOURCES.map((src) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: `community-map__source-tab ${filterSource === src ? "community-map__source-tab--active" : ""}`,
                  onClick: () => setFilterSource(src),
                  children: src === "全部" ? "🎰 全部" : src === "台灣彩券" ? "🎫 台彩" : "⚽ 運彩"
                },
                src
              )) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: "community-map__filter-btn",
                  onClick: () => setShowFilters(!showFilters),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Funnel, { size: 16 }),
                    "縣市篩選",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { size: 14, className: showFilters ? "rotate-180" : "" })
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: `community-map__filter-btn ${showOnlyJackpot ? "community-map__filter-btn--active-jackpot" : ""}`,
                  onClick: () => setShowOnlyJackpot(!showOnlyJackpot),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Trophy, { size: 14 }),
                    " 僅頭獎"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: `community-map__filter-btn ${activeTags.length > 0 ? "community-map__filter-btn--active" : ""}`,
                  onClick: () => setShowTagFilters(!showTagFilters),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { size: 16 }),
                    "設施篩選 ",
                    activeTags.length > 0 && `(${activeTags.length})`
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: "community-map__checkin-toggle",
                  onClick: () => setShowCheckin(!showCheckin),
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { size: 16 }),
                    "中獎打卡"
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: showFilters && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                className: "community-map__city-filter",
                initial: { opacity: 0, height: 0 },
                animate: { opacity: 1, height: "auto" },
                exit: { opacity: 0, height: 0 },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: `community-map__city-chip ${!filterCity ? "community-map__city-chip--active" : ""}`,
                      onClick: () => {
                        setFilterCity("");
                        setFilterDistrict("");
                      },
                      children: "全部縣市"
                    }
                  ),
                  CITIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      className: `community-map__city-chip ${filterCity === c ? "community-map__city-chip--active" : ""}`,
                      onClick: () => {
                        setFilterCity(c);
                        setFilterDistrict("");
                      },
                      children: [
                        c,
                        cityStats[c] && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__city-count", children: cityStats[c].total })
                      ]
                    },
                    c
                  )),
                  filterCity && availableDistricts.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__district-filter", style: { width: "100%", marginTop: "0.5rem", borderTop: "1px dashed var(--border-subtle)", paddingTop: "0.5rem", display: "flex", flexWrap: "wrap", gap: "0.35rem" }, children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        className: `community-map__city-chip ${!filterDistrict ? "community-map__city-chip--active" : ""}`,
                        onClick: () => setFilterDistrict(""),
                        children: "全部區域"
                      }
                    ),
                    availableDistricts.map((d) => {
                      const districtCount = retailers.filter((r) => normalizeCity(r.city) === normalizeCity(filterCity) && r.district === d).length;
                      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          className: `community-map__city-chip ${filterDistrict === d ? "community-map__city-chip--active" : ""}`,
                          onClick: () => setFilterDistrict(d),
                          children: [
                            d,
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__city-count", children: districtCount })
                          ]
                        },
                        d
                      );
                    })
                  ] })
                ]
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: showTagFilters && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                className: "community-map__tag-filter",
                initial: { opacity: 0, height: 0 },
                animate: { opacity: 1, height: "auto" },
                exit: { opacity: 0, height: 0 },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__tag-chips", children: TAG_FILTERS.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: `community-map__tag-chip ${activeTags.includes(t.key) ? "community-map__tag-chip--active" : ""}`,
                      onClick: () => toggleTag(t.key),
                      children: t.label
                    },
                    t.key
                  )) }),
                  activeTags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      className: "community-map__tag-clear",
                      onClick: () => setActiveTags([]),
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 14 }),
                        " 清除篩選"
                      ]
                    }
                  )
                ]
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: showCheckin && /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                className: "community-map__checkin-form glass-card",
                initial: { opacity: 0, height: 0 },
                animate: { opacity: 1, height: "auto" },
                exit: { opacity: 0, height: 0 },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 18 }),
                    " 回報中獎"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__form-row", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("select", { value: city, onChange: (e) => setCity(e.target.value), children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "選擇縣市" }),
                      CITIES.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: c, children: c }, c))
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "number",
                        placeholder: "中獎金額",
                        value: amount,
                        onChange: (e) => setAmount(e.target.value)
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        placeholder: "款式名稱（選填）",
                        value: gameName,
                        onChange: (e) => setGameName(e.target.value)
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        className: "community-map__submit-btn",
                        onClick: handleSubmit,
                        disabled: submitting || !city || !amount,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { size: 14 }),
                          submitting ? "送出中..." : "送出打卡"
                        ]
                      }
                    )
                  ] })
                ]
              }
            ) })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.section,
        {
          className: "community-map__stats-row",
          initial: { opacity: 0, y: 20 },
          animate: { opacity: 1, y: 0 },
          transition: { delay: 0.15 },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__stat glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 20 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "彩券行" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: retailers.filter((r) => r.source === "台灣彩券").length.toLocaleString() })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__stat glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 20 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "運彩行" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: retailers.filter((r) => r.source === "台灣運彩").length.toLocaleString() })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__stat glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Navigation, { size: 20 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "搜尋結果" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: filtered.length.toLocaleString() })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__stat glass-card", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { size: 20 }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "中獎回報" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: checkins.length })
              ] })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__main-layout", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "community-map__retailers", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__list-header", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__list-title-row", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { children: "🏪 投注站列表" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__view-toggled", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    className: `community-map__view-btn ${viewMode === "list" ? "active" : ""}`,
                    onClick: () => setViewMode("list"),
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(List, { size: 16 }),
                      " 列表"
                    ]
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "button",
                  {
                    className: `community-map__view-btn ${viewMode === "map" ? "active" : ""}`,
                    onClick: () => setViewMode("map"),
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Map$1, { size: 16 }),
                      " 地圖"
                    ]
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__result-count", children: [
              "顯示 ",
              displayedRetailers.length,
              " / ",
              filtered.length,
              " 間"
            ] })
          ] }),
          loadingRetailers ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__loading", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "spinner" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "載入經銷商資料中..." })
          ] }) : filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__empty", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 48 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "找不到符合條件的投注站" })
          ] }) : viewMode === "map" ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__map-view glass-card", style: { padding: 0, overflow: "hidden" }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            MapContainer,
            {
              center: [23.6978, 120.9605],
              zoom: 7,
              style: { height: "700px", width: "100%", zIndex: 0 },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  TileLayer,
                  {
                    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  }
                ),
                heatmapPoints.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(HeatmapLayer, { points: heatmapPoints }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  ClusteredMarkers,
                  {
                    retailers: filtered,
                    getGoogleMapsUrl,
                    openInventoryReport,
                    setRatingRetailer,
                    officialInventoryCache,
                    onMarkerClick: handleMarkerClick
                  }
                )
              ]
            }
          ) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__retailer-grid", children: displayedRetailers.map((r, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              motion.div,
              {
                className: `community-map__retailer-card glass-card ${r.merchantTier === "pro" ? "community-map__retailer-card--pro" : ""}`,
                onClick: () => handleRetailerClick(r.id),
                initial: { opacity: 0, y: 10 },
                animate: { opacity: 1, y: 0 },
                transition: { delay: Math.min(idx * 0.02, 0.5) },
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__retailer-header", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "community-map__retailer-name", children: [
                      r.name,
                      r.jackpotCount && r.jackpotCount > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__badge community-map__badge--jackpot", title: `已開出 ${r.jackpotCount} 次頭獎`, children: [
                        "🏆 ",
                        r.jackpotCount,
                        " 次頭獎"
                      ] }) : null,
                      r.isClaimed && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__badge community-map__badge--verified", title: "已認證店家", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { size: 12 }),
                        " 認證"
                      ] }),
                      r.merchantTier === "pro" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__badge community-map__badge--pro", title: "專業版店家", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 12 }),
                        " PRO"
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `community-map__retailer-source ${r.source === "台灣彩券" ? "community-map__retailer-source--lottery" : "community-map__retailer-source--sport"}`, children: [
                      r.source === "台灣彩券" ? "🎫" : "⚽",
                      " ",
                      r.source
                    ] })
                  ] }),
                  r.announcement && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__announcement", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { size: 14 }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: r.announcement })
                  ] }),
                  r.merchantTier === "pro" && getActiveFacilities(r).length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__facility-tags", children: getActiveFacilities(r).map((f) => /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__facility-tag", title: FACILITY_LABELS[f], children: [
                    FACILITY_ICONS[f],
                    " ",
                    FACILITY_LABELS[f]
                  ] }, f)) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "community-map__retailer-address", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 14 }),
                    r.address
                  ] }),
                  inventoryCache[r.id] && inventoryCache[r.id].length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__inventory-lights", children: inventoryCache[r.id].map((inv) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: `community-map__inv-dot community-map__inv-dot--${inv.status === "充足" ? "green" : inv.status === "少量" ? "yellow" : "red"}`,
                      title: `${inv.item}: ${inv.status}`,
                      children: inv.item.replace("元刮刮樂", "")
                    },
                    inv.item
                  )) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__retailer-meta", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__retailer-district", children: [
                      r.city,
                      " · ",
                      r.district
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__retailer-actions", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          className: "community-map__report-btn",
                          onClick: () => openInventoryReport(r),
                          title: "回報庫存",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { size: 13 }),
                            " 庫存"
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          className: "community-map__report-btn",
                          onClick: () => setRatingRetailer(r),
                          title: "評分",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { size: 13 }),
                            " 評分"
                          ]
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "a",
                        {
                          href: getGoogleMapsUrl(r),
                          target: "_blank",
                          rel: "noopener noreferrer",
                          className: "community-map__map-link",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { size: 14 }),
                            "導航"
                          ]
                        }
                      ),
                      !r.isClaimed && /* @__PURE__ */ jsxRuntimeExports.jsx(
                        Link,
                        {
                          to: `/merchant/claim/${r.id}`,
                          className: "community-map__report-btn",
                          style: { textDecoration: "none", background: "#e0f2fe", color: "#0369a1", whiteSpace: "nowrap" },
                          children: "🙋‍♂️ 認領"
                        }
                      )
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(RatingDisplay, { retailerId: r.id, compact: true })
                ]
              },
              r.id
            )) }),
            hasMore && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "community-map__load-more", onClick: handleLoadMore, children: [
              "載入更多（還有 ",
              filtered.length - displayCount,
              " 間）"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "community-map__sidebar", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__heatmap glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { size: 18 }),
              " 全台中獎熱區"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__heatmap-grid", children: CITIES.map((c) => {
              const stat = checkinStats[c];
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: `community-map__heat-item ${stat ? "community-map__heat-item--active" : ""}`,
                  onClick: () => {
                    setFilterCity(c);
                    setShowFilters(true);
                  },
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: c }),
                    stat ? /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
                      "$",
                      stat.total.toLocaleString()
                    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__heat-empty", children: "—" })
                  ]
                },
                c
              );
            }) })
          ] }),
          checkins.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__recent glass-card", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { children: "📋 最新打卡" }),
            checkins.slice(0, 10).map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__checkin-item", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 14 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__checkin-city", children: c.city }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__checkin-amount", children: [
                "$",
                c.amount.toLocaleString()
              ] }),
              c.gameName && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__checkin-game", children: c.gameName })
            ] }, c.id))
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: showInventoryReport && inventoryRetailer && /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.div,
      {
        className: "community-map__modal-overlay",
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        onClick: () => setShowInventoryReport(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          motion.div,
          {
            className: "community-map__modal glass-card",
            initial: { opacity: 0, scale: 0.9 },
            animate: { opacity: 1, scale: 1 },
            exit: { opacity: 0, scale: 0.9 },
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__modal-header", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Package, { size: 18 }),
                  " 回報庫存"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setShowInventoryReport(false), children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { size: 18 }) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "community-map__modal-store", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Store, { size: 14 }),
                " ",
                inventoryRetailer.name
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__modal-section", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "搜尋刮刮樂款式（名稱或期數）" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    className: "community-map__report-search",
                    placeholder: "輸入款式名稱或期數...",
                    value: reportSearchInput,
                    onChange: async (e) => {
                      const val = e.target.value;
                      setReportSearchInput(val);
                      setReportSearchLoading(true);
                      try {
                        const results = await searchScratchcardsPublic(val);
                        setReportSearchResults(results);
                      } catch {
                        setReportSearchResults([]);
                      } finally {
                        setReportSearchLoading(false);
                      }
                    }
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__report-results", children: [
                  reportSearchLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__report-loading", children: "搜尋中..." }),
                  !reportSearchLoading && reportSearchResults.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__report-empty", children: "沒有找到符合的款式" }),
                  !reportSearchLoading && reportSearchResults.map((card) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      className: `community-map__report-item ${inventoryItem === `${card.name} ($${card.price})` ? "community-map__report-item--active" : ""}`,
                      onClick: () => setInventoryItem(`${card.name} ($${card.price})`),
                      children: [
                        card.imageUrl && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: card.imageUrl, alt: card.name, className: "community-map__report-item-img" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__report-item-info", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "community-map__report-item-name", children: card.name }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "community-map__report-item-meta", children: [
                            "期數 ",
                            card.gameId,
                            " ・$",
                            card.price
                          ] })
                        ] })
                      ]
                    },
                    card.id
                  ))
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "community-map__modal-section", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { children: "庫存狀態" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "community-map__modal-options", children: INVENTORY_STATUS.map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: `community-map__modal-opt ${inventoryStatus === s.value ? "community-map__modal-opt--active" : ""}`,
                    onClick: () => setInventoryStatus(s.value),
                    style: inventoryStatus === s.value ? { borderColor: s.color, color: s.color } : {},
                    children: s.label
                  },
                  s.value
                )) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  className: "community-map__modal-submit",
                  onClick: handleInventoryReport,
                  disabled: reportingInventory || !inventoryItem || !inventoryStatus || !user,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { size: 14 }),
                    reportingInventory ? "送出中..." : "送出回報"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "community-map__modal-hint", children: "📍 系統將自動取得您的 GPS 位置以驗證距離" })
            ]
          }
        )
      }
    ) }),
    ratingRetailer && /* @__PURE__ */ jsxRuntimeExports.jsx(
      RatingPanel,
      {
        retailerId: ratingRetailer.id,
        retailerName: ratingRetailer.name,
        onClose: () => setRatingRetailer(null),
        onSubmitted: () => setRatingRetailer(null)
      }
    )
  ] });
}
export {
  CommunityMap as default
};
//# sourceMappingURL=CommunityMap-DQ6CrTUJ.js.map
